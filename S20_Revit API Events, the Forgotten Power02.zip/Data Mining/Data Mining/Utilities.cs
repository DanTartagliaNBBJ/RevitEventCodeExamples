﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Text;
using System.Windows.Forms;

namespace DataMining
{
    public class Utilities
    {
        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the user's country code for use with dates/times
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>05/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string CountryCodeGet()
        {
            // Get the name of the current country
            string strCountry = System.Globalization.RegionInfo.CurrentRegion.EnglishName;

            // Set the country code as needed
            switch (strCountry)
            {
                case "United States":
                    return "en-US";

                case "United Kingdom":
                    return "en-GB";

                case "People's Republic of China":
                    return "zh-CN";

                default:
                    return "en-US";
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the file size
        /// </summary>
        /// <returns> long </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static long FileSizeGet(string strFilePathName)
        {
            try
            {
                FileInfo fInfo = new FileInfo(strFilePathName);
                return fInfo.Length / 1024;
            }
            catch
            {
                return 0;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determines if one string is within the other
        /// </summary>
        /// <returns> integer </returns>
        /// <author>Dan.Tartaglia </author>                              <date>01/2010</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static int IsStringFound(String strValue, String strPath)
        {
            return (strPath.IndexOf(strValue));
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get Environment Variable value
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>09/2012</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string EnvironmentVariableGet(string strVarName)
        {
            // Get the environment variable value
            return Environment.GetEnvironmentVariable(strVarName);
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get DLL File Version value
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>11/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string GetFileVersion()
        {
            try
            {
                Assembly oAssembly = Assembly.GetExecutingAssembly();
                FileVersionInfo oFileVersionInfo = FileVersionInfo.GetVersionInfo(oAssembly.Location);
                return oFileVersionInfo.FileVersion;
            }
            catch
            {
                return string.Empty;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get hard drive space data
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static double HDDataGet(string strDrive, DefaultValues.HardDriveValues oHardDriveValues)
        {
            try
            {
                // Get hard drive space data
                long lngFreeSpace = HDSpaceGet(strDrive, oHardDriveValues);

                if (lngFreeSpace == -1)
                    return -1;
                else
                {
                    // Convert and round the value
                    int byteConversion = 1024;
                    double dblFreeSpace = Convert.ToDouble(lngFreeSpace);
                    dblFreeSpace = Math.Round(dblFreeSpace / Math.Pow(byteConversion, 3), 2);
                    return dblFreeSpace;
                }
            }
            catch
            {
                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get folder size
        /// </summary>
        /// <returns> double </returns>
        /// <author>Dan.Tartaglia </author>                              <date>01/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static double DirectorySizeGet(string strFolder)
        {
            var files = Directory.EnumerateFiles(strFolder);

            // get the sizeof all files in the current directory
            var currentSize = (from file in files let fileInfo = new FileInfo(file) select fileInfo.Length).Sum();

            var directories = Directory.EnumerateDirectories(strFolder);

            // get the size of all files in all subdirectories
            var subDirSize = (from directory in directories select DirectorySizeGet(directory)).Sum();

            return currentSize + subDirSize;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get hard drive space for specific purpose
        /// </summary>
        /// <returns> long </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static long HDSpaceGet(string driveName, DefaultValues.HardDriveValues oHardDriveValues)
        {
            // Iterate through each
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady && drive.Name.ToUpper() == driveName.ToUpper())
                {
                    if (oHardDriveValues == DefaultValues.HardDriveValues.Free)
                        return drive.TotalFreeSpace;
                    else if (oHardDriveValues == DefaultValues.HardDriveValues.Total)
                        return drive.TotalSize;
                }
            }
            return -1;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Deterime if wireless is enabled or not on the computer
        /// </summary>
        /// <returns> bool </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static bool IsWirelessEnabled()
        {
            NetworkInterface[] networkCards = NetworkInterface.GetAllNetworkInterfaces();
            bool connected = false;
            bool WirelessEnabled = false;

            foreach (NetworkInterface nc in networkCards)
            {
                if (nc.NetworkInterfaceType == NetworkInterfaceType.Wireless80211)
                {
                    if (nc.OperationalStatus == OperationalStatus.Up)
                        WirelessEnabled = true;
                }
            }

            if (WirelessEnabled == true)
            {
                foreach (NetworkInterface nc in networkCards)
                {
                    if (nc.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
                    {
                        // Return false if both wireless and ethernet are up
                        if (nc.OperationalStatus == OperationalStatus.Up && WirelessEnabled == true)
                            connected = false;

                        // Return true if only wireless is enabled
                        else if (WirelessEnabled == true)
                            connected = true;
                    }
                }
            }
            return connected;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get Available Physical Memory
        /// </summary>
        /// <returns> ulong </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static ulong GetAvailMemoryInBytes()
        {
            return new Microsoft.VisualBasic.Devices.ComputerInfo().AvailablePhysicalMemory;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the total (recursive) number of files in a folder
        /// </summary>
        /// <returns> IEnumerable<string> </returns>
        /// <author>Dan.Tartaglia </author>                              <date>01/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static IEnumerable<string> DirectoryFileNumberGet(string strPath, string strSearchPattern)
        {
            Stack<string> pending = new Stack<string>();
            pending.Push(strPath);
            while (pending.Count != 0)
            {
                var path = pending.Pop();
                string[] next = null;
                try
                {
                    next = Directory.GetFiles(path, strSearchPattern);
                }
                catch
                {
                }
                if (next != null && next.Length != 0)
                    foreach (var file in next) yield return file;
                try
                {
                    next = Directory.GetDirectories(path);
                    foreach (var subdir in next) pending.Push(subdir);
                }
                catch
                {
                }
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Write to the output text file
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>01/2013</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void TextFileWrite(string strTextFileName, string strValue, bool blnAppend)
        {
            try
            {
                // create a writer and open the file
                TextWriter tw = new StreamWriter(strTextFileName, blnAppend);

                // Add a line of text to the output file
                tw.WriteLine(strValue);

                // close the stream
                tw.Close();
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the full path for the wanted C4R file
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string RVTFullPathGet(List<string> lstBasicfileinfoFullPaths, string strDocPathName)
        {
            string strRVTGUIDFullPath = string.Empty;

            try
            {
                // Iterate through each basicfileinfo path
                foreach (string strValue in lstBasicfileinfoFullPaths)
                {
                    // Only process .dat files
                    if (!strValue.EndsWith(".dat"))
                        continue;

                    // Get the 2nd string in the current basicfileinfo file
                    string strRVTFullPath = TextFileReadGetByLineNumber(2, strValue);

                    if (strRVTFullPath.Equals(string.Empty))
                        return string.Empty;

                    // Remove these charaters from the string
                    string strRVTFullPathModified = strRVTFullPath.Replace("\0", string.Empty);

                    // Keep processing if the current file path name is found in the string
                    if (IsStringFound(Path.GetFileName(strDocPathName), strRVTFullPathModified) < 0)
                        continue;

                    // Get the string starting with 'last path' from the current basicfileinfo file
                    string strRVTGUIDValue = TextFileReadGetLineByBegText("\0L\0a\0s\0t\0 \0S\0a\0v\0e\0 \0P\0a\0t\0h", strValue);

                    // The file path name should be found, if not keep trying other basicfileinfo files
                    if (strRVTGUIDValue.Equals(string.Empty))
                        return string.Empty;

                    // Remove these charaters from the string
                    string strRVTGUIDFullPathModified = strRVTGUIDValue.Replace("\0", string.Empty);

                    // Remove the beginning part of the string to extract the file path name
                    strRVTGUIDFullPath = strRVTGUIDFullPathModified.Remove(0, 16);
                }
            }
            catch
            {
                return string.Empty;
            }
            return strRVTGUIDFullPath;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get lines of text from the text file as per the line number
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string TextFileReadGetByLineNumber(int intLine, string strFullPath)
        {
            int intCntr = 0;
            string strLine = string.Empty;
            List<string> lstTemp = new List<string>();

            try
            {
                // Open the text file read-only                
                var oFileStream = new FileStream(strFullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using (var oStreamReader = new StreamReader(oFileStream))
                {
                    // Iterate through each line of text
                    while ((strLine = oStreamReader.ReadLine()) != null)
                    {
                        intCntr++;

                        if (intLine == intCntr)
                            return strLine;
                    }
                }

                // Close the file
                oFileStream.Close();
            }
            catch
            {
                return string.Empty;
            }
            return string.Empty;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get lines of text from the text file as per the beginning value of the line
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string TextFileReadGetLineByBegText(string strValue, string strFullPath)
        {
            int intCntr = 0;
            string strLine = string.Empty;
            List<string> lstTemp = new List<string>();

            try
            {
                // Open the text file read-only                
                var oFileStream = new FileStream(strFullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using (var oStreamReader = new StreamReader(oFileStream))
                {
                    // Iterate through each line of text
                    while ((strLine = oStreamReader.ReadLine()) != null)
                    {
                        intCntr++;

                        if (strLine.StartsWith(strValue))
                            return strLine;
                    }
                }

                // Close the file
                oFileStream.Close();
            }
            catch
            {
                return string.Empty;
            }
            return string.Empty;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the basicfileinfo file names
        /// </summary>
        /// <returns> List<string> </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static List<string> BasicfileinfoFilesGet(string strSearchValue, string strCollaborationCachePath)
        {
            List<string> strTemp = new List<string>();

            try
            {
                // Get the info from the given folder
                DirectoryInfo oDirectoryInfo = new DirectoryInfo(strCollaborationCachePath);

                // Iterate through each file
                foreach (var oFileInfo in oDirectoryInfo.GetFiles(strSearchValue + "*", SearchOption.AllDirectories))
                {
                    try
                    {
                        strTemp.Add(oFileInfo.FullName);
                    }
                    catch
                    {
                        continue;
                    }
                }
            }
            catch
            {
                strTemp = new List<string>();
                return strTemp;
            }
            return strTemp;
        }
    }
}
