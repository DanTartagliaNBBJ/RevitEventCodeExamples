﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataMining
{
    public class DefaultValues
    {
        // Env Variables
        public static string strRevitVersionNumber = "2019";                         
        public static string strErrorLog = @"C:\Users\dtartaglia\Documents\Dans-stuff\Conferences\Digital Built Week\2019\Revit API Events\Examples\Data Mining\ErrorLog.csv";
        public static string strRevitC4RBuildNumber = @"C:\Program Files\Autodesk\Collaboration for Revit 2019\Collaborate.dll";
        public static string strRevitAcceleratorBuildNumber = @"C:\Program Files\Autodesk\Personal Accelerator for Revit\RevitAccelerator.exe";
        public static string strRevitDesktopConnectorBuildNumber = @"C:\Program Files\Autodesk\Desktop Connector\DesktopConnector.Applications.Tray.exe";
        public static string strRevitVersion = "Autodesk Revit 2019";
        public static string strC4RAppendedValue01 = "A360:";
        public static string strC4RAppendedValue02 = "BIM 360:";
        public static string strCollaborationCachePath = Environment.GetEnvironmentVariable("LOCALAPPDATA") +
            @"\Autodesk\Revit\" + strRevitVersion + @"\CollaborationCache\";
        public static string strCSVLogFilePath = @"C:\Users\dtartaglia\Documents\Dans-stuff\Conferences\Digital Built Week\2019\Revit API Events\Examples\Data Mining\Data Mining.csv";

        public enum HardDriveValues : uint
        {
            Total = 0,
            Free = 1
        }

        public enum RevitFilePathValues : uint
        {
            Path = 0,
            Name = 1,
            DateCreated = 2,
            TimeCreated = 3,
            DateModified = 4,
            TimeModified = 5,
            FileSize = 6
        }

        public enum RevitCadObjects : uint
        {
            Links = 0,
            Imports = 1
        }

        public List<string> lstBasicfileinfoFullPaths { get; set; } = null;
    }
}
