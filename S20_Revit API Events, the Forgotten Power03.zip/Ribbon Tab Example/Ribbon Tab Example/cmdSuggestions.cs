﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

namespace RibbonTabExample
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class cmdSuggestions : IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData revit,
           ref string message, ElementSet elements)
        {
            try
            {
                // Keep processing only if Outlook is running
                if (ProcessExist("OUTLOOK") == false)
                {
                    MessageBox.Show("Please launch Outlook before using this tool", "Outlook is not open",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return Autodesk.Revit.UI.Result.Succeeded;
                }

                // Create and send the email via Outlook
                EmailProcess();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return Autodesk.Revit.UI.Result.Succeeded;
            }

            return Autodesk.Revit.UI.Result.Succeeded;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determine if a given Window's process is currently running
        /// </summary>
        /// <returns> bool </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static bool ProcessExist(string strProcessName)
        {
            // Get the processes
            Process[] processlist = Process.GetProcesses();

            // Iterate through each process
            foreach (Process theprocess in processlist)
            {
                // Look for the wanted process name
                if (theprocess.ProcessName.ToUpper() == strProcessName)
                    return true;
            }
            return false;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Create and send the email via Outlook
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void EmailProcess()
        {
            List<string> strOutputPrimEmailAddresses = new List<string>();

            try
            {
                strOutputPrimEmailAddresses.Add("ExampleMe@nbbbj.com");
                strOutputPrimEmailAddresses.Add("BIMLeaders@nbbbj.com");

                // Get Outlook object
                Outlook.Application oOutlookApp = new Outlook.Application();
                Outlook.MailItem oMail = oOutlookApp.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;

                // Set the Subject
                oMail.Subject = "Suggestions or ideas for new tools";

                // Set the priority
                oMail.Importance = Outlook.OlImportance.olImportanceHigh;

                // Add each primary email address
                foreach (string strPrimEmailAddress in strOutputPrimEmailAddresses)
                {
                    oMail.Recipients.Add(strPrimEmailAddress);
                }

                // Verify they are valid
                oMail.Recipients.ResolveAll();

                // Add to the email body
                oMail.HTMLBody = "<i>Please add as much information you need to help us understand your idea<i>";

                // Send the email
                oMail.Display();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }

    public class SuggestionsShowButtonAlways : IExternalCommandAvailability
    {
        // Show the button as long as Revit is open
        public bool IsCommandAvailable(Autodesk.Revit.UI.UIApplication applicationData,
            CategorySet selectedCategories)
        {
            return true;
        }
    }
}