﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

namespace RibbonTabExample
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class cmdBIM360 : IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData revit,
           ref string message, ElementSet elements)
        {
            // Open the webpage
            try
            {
                Process.Start("Chrome.exe", "https://health.autodesk.com/");
            }
            catch
            {
                Process.Start("https://health.autodesk.com/");
            }

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class cmdBIM360Docs : IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData revit,
           ref string message, ElementSet elements)
        {
            // Open the webpage
            TaskDialog.Show("Webpage", "Open BIM360 Docs firm page");

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

    public class BIM360ShowButtonAlways : IExternalCommandAvailability
    {
        // Show the button as long as Revit is open
        public bool IsCommandAvailable(Autodesk.Revit.UI.UIApplication applicationData,
            CategorySet selectedCategories)
        {
            return true;
        }
    }
}