﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;

namespace RevitNotifications
{
    class CSVFileWrite
    {
        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Main method to write to CSV log file
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void CSVFileWriteProcess(Globals oGlobals)
        {
            string strStatus = string.Empty;
            string strFullPath = string.Empty;
            string strIssue = string.Empty;
            List<string> lstIssues = new List<string>();

            try
            {
                // Create the folder if needed
                if (!Directory.Exists(Globals.strErrorLogPath))
                    Directory.CreateDirectory(Globals.strErrorLogPath);

                // Create the folder if needed
                if (!Directory.Exists(Globals.strCSVLogFilePath))
                    Directory.CreateDirectory(Globals.strCSVLogFilePath);

                // Verify the file exists
                if (!File.Exists(Globals.strCSVLogFilePath + Globals.strCSVLogFileName))
                {
                    // Create the text file and write the header
                    IssuesFind.TextFileWrite(Globals.strCSVLogFilePath + 
                        Globals.strCSVLogFileName, "Date,Studio,User Name,Computer Name,Issue,Status,Value,Revit Version,Full Path", false);
                }

                // Available RAM
                if (oGlobals.blnRAMAvailFlag == true)
                {
                    // Get the status
                    if (oGlobals.blnRAMAvailRed == true)
                        strStatus = "Red";
                    else
                        strStatus = "Orange";

                    // Format the issue string
                    strIssue = CompileIssueString(strStatus, oGlobals.strTitleValue01, oGlobals.strValue01, oGlobals);

                    if (!strIssue.Equals(string.Empty))
                        // Add to the list
                        lstIssues.Add(strIssue);
                }

                // Free Hard Drive Space
                if (oGlobals.blnHDSpaceFreeFlag == true)
                {
                    // Get the status
                    if (oGlobals.blnHDSpaceFreeRed == true)
                        strStatus = "Red";
                    else
                        strStatus = "Orange";

                    // Format the issue string
                    strIssue = CompileIssueString(strStatus, oGlobals.strTitleValue02, oGlobals.strValue02, oGlobals);

                    if (!strIssue.Equals(string.Empty))
                        // Add to the list
                        lstIssues.Add(strIssue);
                }

                // Wi-Fi Enabled?
                if (oGlobals.blnWiFiEnabledFlag == true)
                {
                    strStatus = "Red";

                    // Format the issue string
                    strIssue = CompileIssueString(strStatus, oGlobals.strTitleValue03, oGlobals.strValue03, oGlobals);

                    if (!strIssue.Equals(string.Empty))
                        // Add to the list
                        lstIssues.Add(strIssue);
                }

                // Opened Central File?
                if (oGlobals.blnCentralFileOpenFlag == true)
                {
                    strStatus = "Red";

                    // Format the issue string
                    strIssue = CompileIssueString(strStatus, oGlobals.strTitleValue04, oGlobals.strValue04, oGlobals);

                    if (!strIssue.Equals(string.Empty))
                        // Add to the list
                        lstIssues.Add(strIssue);
                }

                // Users in the Model
                if (oGlobals.blnUsersInModelFlag == true)
                {
                    // Get the status
                    if (oGlobals.blnUsersInModelRed == true)
                        strStatus = "Red";
                    else
                        strStatus = "Orange";

                    // Format the issue string
                    strIssue = CompileIssueString(strStatus, oGlobals.strTitleValue05, oGlobals.strValue05, oGlobals);

                    if (!strIssue.Equals(string.Empty))
                        // Add to the list
                        lstIssues.Add(strIssue);
                }

                // Working over WAN
                if (oGlobals.blnWorkingOverWANFlag == true)
                {
                    strStatus = "Red";

                    // Format the issue string
                    strIssue = CompileIssueString(strStatus, oGlobals.strTitleValue06, oGlobals.strValue06, oGlobals);

                    if (!strIssue.Equals(string.Empty))
                        // Add to the list
                        lstIssues.Add(strIssue);
                }

                // Iterate through each string
                foreach (string strValue in lstIssues)
                {
                    // Write to the log file
                    IssuesFind.TextFileWrite(Globals.strCSVLogFilePath +
                        Globals.strCSVLogFileName, strValue, true);
                }
            }
            catch(Exception ex)
            {
                // Write error message
                IssuesFind.ErrorLogProcess(ex.Message, "CSVFileWriteProcess");
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Create/compile the string for the CSV log file
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string CompileIssueString(string strStatus, string strTitleValue, 
            string strValue, Globals oGlobals)
        {
            string strFullPath = string.Empty;
            string strVersionName = string.Empty;

            try
            {
                try
                {
                    // Get the ModelPath of the document if worksharing is enabled
                    ModelPath oModelPath = IssuesFind.WSModelPathGet(ApplicationClass.m_RevitDocument);

                    // Central file full path
                    if (oModelPath != null)
                        strFullPath = Email.RevitFilePathValueGet(oModelPath, ApplicationClass.m_RevitDocument);
                    else
                        strFullPath = string.Empty;
                }
                catch
                {
                    strFullPath = string.Empty;
                }

                try
                {
                    // Get the Revit version
                    strVersionName = ApplicationClass.m_RevitDocument.Application.VersionName;
                }
                catch
                {
                    strVersionName = string.Empty;
                }

                // Return the compiled string
                return Email.DateTimeCurrentGet() + "," +
                            oGlobals.strUserStudioCode + "," +
                            oGlobals.strUserName + "," +
                            Email.EnvironmentVariableGet("COMPUTERNAME") + "," +
                            strTitleValue + "," +
                            strStatus + "," +
                            strValue + "," +
                            strVersionName + "," +
                            strFullPath;
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
