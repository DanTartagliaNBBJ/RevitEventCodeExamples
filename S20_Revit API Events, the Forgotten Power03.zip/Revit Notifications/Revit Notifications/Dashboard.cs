﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.DB;

namespace RevitNotifications
{
    public partial class Dashboard : System.Windows.Forms.Form
    {       
        public Dashboard()
        {
            InitializeComponent();

            int intCntr = 0;

            lblVersion.Text = Globals.strAppVersion;

            List<Label> lstTitleValues = new List<Label>();
            List<Label> lstValues = new List<Label>();
            List<Label> lstLinkLabels = new List<Label>();
            List<Label> lstLinkValues = new List<Label>();
            List<PictureBox> lstOrangeValues = new List<PictureBox>();
            List<PictureBox> lstRedValues = new List<PictureBox>();
            List<int> DashboardSizeValues = new List<int>();

            lstTitleValues.Add(lblTitle01);
            lstTitleValues.Add(lblTitle02);
            lstTitleValues.Add(lblTitle03);
            lstTitleValues.Add(lblTitle04);
            lstTitleValues.Add(lblTitle05);
            lstTitleValues.Add(lblTitle06);

            lstValues.Add(lblValue01);
            lstValues.Add(lblValue02);
            lstValues.Add(lblValue03);
            lstValues.Add(lblValue04);
            lstValues.Add(lblValue05);
            lstValues.Add(lblValue06);

            lstLinkLabels.Add(lblLinkLabel01);
            lstLinkLabels.Add(lblLinkLabel02);
            lstLinkLabels.Add(lblLinkLabel03);
            lstLinkLabels.Add(lblLinkLabel04);
            lstLinkLabels.Add(lblLinkLabel05);
            lstLinkLabels.Add(lblLinkLabel06);

            lstLinkValues.Add(lblLink01);
            lstLinkValues.Add(lblLink02);
            lstLinkValues.Add(lblLink03);
            lstLinkValues.Add(lblLink04);
            lstLinkValues.Add(lblLink05);
            lstLinkValues.Add(lblLink06);

            lstOrangeValues.Add(pbxOrange01);
            lstOrangeValues.Add(pbxOrange02);
            lstOrangeValues.Add(pbxOrange03);
            lstOrangeValues.Add(pbxOrange04);
            lstOrangeValues.Add(pbxOrange05);
            lstOrangeValues.Add(pbxOrange06);

            lstRedValues.Add(pbxRed01);
            lstRedValues.Add(pbxRed02);
            lstRedValues.Add(pbxRed03);
            lstRedValues.Add(pbxRed04);
            lstRedValues.Add(pbxRed05);
            lstRedValues.Add(pbxRed06);

            DashboardSizeValues.Add(242);
            DashboardSizeValues.Add(353);
            DashboardSizeValues.Add(464);
            DashboardSizeValues.Add(575);
            DashboardSizeValues.Add(686);
            DashboardSizeValues.Add(797);

            if (ApplicationClass.m_RevitDocument != null)
            {
                // Get the ModelPath of the document if worksharing is enabled
                ModelPath oModelPath = IssuesFind.WSModelPathGet(ApplicationClass.m_RevitDocument);

                // Get central file name
                lblFileName.Text = 
                    Path.GetFileName(IssuesFind.RevitFileCentralFullPathGet(oModelPath, ApplicationClass.m_RevitDocument));
            }
 
            // Create the ToolTip and associate with the Form container.
            System.Windows.Forms.ToolTip toolTip1 = new System.Windows.Forms.ToolTip();

            // Set up the tool tips
            toolTip1.AutoPopDelay = 20000;
            toolTip1.InitialDelay = 500;
            toolTip1.ReshowDelay = 500;

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxRed01, "Immediate Action Needed!");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxRed02, "Immediate Action Needed!");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxRed03, "Immediate Action Needed!");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxRed04, "Immediate Action Needed!");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxRed05, "Immediate Action Needed!");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxRed06, "Immediate Action Needed!");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxOrange01, "Warning, Houston we have a problem ");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxOrange02, "Warning, Houston we have a problem ");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxOrange03, "Warning, Houston we have a problem ");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxOrange04, "Warning, Houston we have a problem ");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxOrange05, "Warning, Houston we have a problem ");

            // Set up the ToolTip text
            toolTip1.SetToolTip(pbxOrange06, "Warning, Houston we have a problem ");

            // Set controls to non-visible
            for (int i = 0; i <= lstTitleValues.Count - 1; i++)
            {
                lstTitleValues[i].Visible = false;
            }

            // Set controls to non-visible
            for (int i = 0; i <= lstValues.Count - 1; i++)
            {
                lstValues[i].Visible = false;
            }

            // Set controls to non-visible
            for (int i = 0; i <= lstLinkLabels.Count - 1; i++)
            {
                lstLinkLabels[i].Visible = false;
            }

            // Set controls to non-visible
            for (int i = 0; i <= lstLinkValues.Count - 1; i++)
            {
                lstLinkValues[i].Visible = false;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Avaiable RAM
            /*--------------+---------------+---------------+---------------+---------------+------*/
            if (IssuesFind.oGlobals.blnRAMAvailFlag == true)
            {
                if (IssuesFind.oGlobals.blnRAMAvailRed == true)
                    lstRedValues[intCntr].Visible = true;
                else
                    lstOrangeValues[intCntr].Visible = true;                

                lstTitleValues[intCntr].Text = IssuesFind.oGlobals.strTitleValue01;
                lstValues[intCntr].Text = IssuesFind.oGlobals.strValue01;
                lstLinkValues[intCntr].Text = IssuesFind.oGlobals.strLinkValue01;

                lstTitleValues[intCntr].Visible = true;
                lstValues[intCntr].Visible = true;
                lstLinkLabels[intCntr].Visible = true;
                lstLinkValues[intCntr].Visible = true;

                this.Size = new System.Drawing.Size(this.Size.Width, DashboardSizeValues[intCntr]);
                intCntr++;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Free Hard Drive Space
            /*--------------+---------------+---------------+---------------+---------------+------*/
            if (IssuesFind.oGlobals.blnHDSpaceFreeFlag == true)
            {
                if (IssuesFind.oGlobals.blnHDSpaceFreeRed == true)
                    lstRedValues[intCntr].Visible = true;
                else
                    lstOrangeValues[intCntr].Visible = true;

                lstTitleValues[intCntr].Text = IssuesFind.oGlobals.strTitleValue02;
                lstValues[intCntr].Text = IssuesFind.oGlobals.strValue02;
                lstLinkValues[intCntr].Text = IssuesFind.oGlobals.strLinkValue02;

                lstTitleValues[intCntr].Visible = true;
                lstValues[intCntr].Visible = true;
                lstLinkLabels[intCntr].Visible = true;
                lstLinkValues[intCntr].Visible = true;

                this.Size = new System.Drawing.Size(this.Size.Width, DashboardSizeValues[intCntr]);
                intCntr++;
            }
 
            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Wi-Fi enabled
            /*--------------+---------------+---------------+---------------+---------------+------*/
            if (IssuesFind.oGlobals.blnWiFiEnabledFlag == true)
            {
                lstRedValues[intCntr].Visible = true;

                lstTitleValues[intCntr].Text = IssuesFind.oGlobals.strTitleValue03;
                lstValues[intCntr].Text = IssuesFind.oGlobals.strValue03;
                lstLinkValues[intCntr].Text = IssuesFind.oGlobals.strLinkValue03;

                lstTitleValues[intCntr].Visible = true;
                lstValues[intCntr].Visible = true;
                lstLinkLabels[intCntr].Visible = true;
                lstLinkValues[intCntr].Visible = true;

                this.Size = new System.Drawing.Size(this.Size.Width, DashboardSizeValues[intCntr]);
                intCntr++;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Opened central file
            /*--------------+---------------+---------------+---------------+---------------+------*/
            if (IssuesFind.oGlobals.blnCentralFileOpenFlag == true)
            {
                lstRedValues[intCntr].Visible = true;

                lstTitleValues[intCntr].Text = IssuesFind.oGlobals.strTitleValue04;
                lstValues[intCntr].Text = IssuesFind.oGlobals.strValue04;
                lstLinkValues[intCntr].Text = IssuesFind.oGlobals.strLinkValue04;

                lstTitleValues[intCntr].Visible = true;
                lstValues[intCntr].Visible = true;
                lstLinkLabels[intCntr].Visible = true;
                lstLinkValues[intCntr].Visible = true;

                this.Size = new System.Drawing.Size(this.Size.Width, DashboardSizeValues[intCntr]);
                intCntr++;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Users in the Model
            /*--------------+---------------+---------------+---------------+---------------+------*/
            if (IssuesFind.oGlobals.blnUsersInModelFlag == true)
            {
                if (IssuesFind.oGlobals.blnUsersInModelRed == true)
                    lstRedValues[intCntr].Visible = true;
                else
                    lstOrangeValues[intCntr].Visible = true;

                lstTitleValues[intCntr].Text = IssuesFind.oGlobals.strTitleValue05;
                lstValues[intCntr].Text = IssuesFind.oGlobals.strValue05;
                lstLinkValues[intCntr].Text = IssuesFind.oGlobals.strLinkValue05;

                lstTitleValues[intCntr].Visible = true;
                lstValues[intCntr].Visible = true;
                lstLinkLabels[intCntr].Visible = true;
                lstLinkValues[intCntr].Visible = true;

                this.Size = new System.Drawing.Size(this.Size.Width, DashboardSizeValues[intCntr]);
                intCntr++;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Working over WAN
            /*--------------+---------------+---------------+---------------+---------------+------*/
            if (IssuesFind.oGlobals.blnWorkingOverWANFlag == true)
            {
                lstRedValues[intCntr].Visible = true;

                lstTitleValues[intCntr].Text = IssuesFind.oGlobals.strTitleValue06;
                lstValues[intCntr].Text = IssuesFind.oGlobals.strValue06;
                lstLinkValues[intCntr].Text = IssuesFind.oGlobals.strLinkValue06;

                lstTitleValues[intCntr].Visible = true;
                lstValues[intCntr].Visible = true;
                lstLinkLabels[intCntr].Visible = true;
                lstLinkValues[intCntr].Visible = true;

                this.Size = new System.Drawing.Size(this.Size.Width, DashboardSizeValues[intCntr]);
                intCntr++;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void lblLinkLabel01_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Set the link value as per the issue
            if (lblTitle01.Text.StartsWith(Globals.strTitleText01))
                Process.Start(Globals.strLinkRam);
            else if (lblTitle01.Text.StartsWith(Globals.strTitleText02))
                Process.Start(Globals.strLinkHDSpace);
            else if (lblTitle01.Text.Equals(Globals.strTitleText03))
                Process.Start(Globals.strLinkWiFi);
            else if (lblTitle01.Text.Equals(Globals.strTitleText04))
                Process.Start(Globals.strLinkOpenedCentralModel);
            else if (lblTitle01.Text.Equals(Globals.strTitleText05))
                Process.Start(Globals.strLinkUsersInModel);
            else if (lblTitle01.Text.Equals(Globals.strTitleText06))
                Process.Start(Globals.strLinkOpenedOverWAN);
            else
                Process.Start(Globals.strLinkElse);
        }

        private void lblLinkLabel02_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Set the link value as per the issue
            if (lblTitle02.Text.StartsWith(Globals.strTitleText01))
                Process.Start(Globals.strLinkRam);
            else if (lblTitle02.Text.StartsWith(Globals.strTitleText02))
                Process.Start(Globals.strLinkHDSpace);
            else if (lblTitle02.Text.Equals(Globals.strTitleText03))
                Process.Start(Globals.strLinkWiFi);
            else if (lblTitle02.Text.Equals(Globals.strTitleText04))
                Process.Start(Globals.strLinkOpenedCentralModel);
            else if (lblTitle02.Text.Equals(Globals.strTitleText05))
                Process.Start(Globals.strLinkUsersInModel);
            else if (lblTitle02.Text.Equals(Globals.strTitleText06))
                Process.Start(Globals.strLinkOpenedOverWAN);
            else
                Process.Start(Globals.strLinkElse);
        }

        private void lblLinkLabel03_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Set the link value as per the issue
            if (lblTitle03.Text.StartsWith(Globals.strTitleText01))
                Process.Start(Globals.strLinkRam);
            else if (lblTitle03.Text.StartsWith(Globals.strTitleText02))
                Process.Start(Globals.strLinkHDSpace);
            else if (lblTitle03.Text.Equals(Globals.strTitleText03))
                Process.Start(Globals.strLinkWiFi);
            else if (lblTitle03.Text.Equals(Globals.strTitleText04))
                Process.Start(Globals.strLinkOpenedCentralModel);
            else if (lblTitle03.Text.Equals(Globals.strTitleText05))
                Process.Start(Globals.strLinkUsersInModel);
            else if (lblTitle03.Text.Equals(Globals.strTitleText06))
                Process.Start(Globals.strLinkOpenedOverWAN);
            else
                Process.Start(Globals.strLinkElse);
        }

        private void lblLinkLabel04_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Set the link value as per the issue
            if (lblTitle04.Text.StartsWith(Globals.strTitleText01))
                Process.Start(Globals.strLinkRam);
            else if (lblTitle04.Text.StartsWith(Globals.strTitleText02))
                Process.Start(Globals.strLinkHDSpace);
            else if (lblTitle04.Text.Equals(Globals.strTitleText03))
                Process.Start(Globals.strLinkWiFi);
            else if (lblTitle04.Text.Equals(Globals.strTitleText04))
                Process.Start(Globals.strLinkOpenedCentralModel);
            else if (lblTitle04.Text.Equals(Globals.strTitleText05))
                Process.Start(Globals.strLinkUsersInModel);
            else if (lblTitle04.Text.Equals(Globals.strTitleText06))
                Process.Start(Globals.strLinkOpenedOverWAN);
            else
                Process.Start(Globals.strLinkElse);
        }

        private void lblLinkLabel05_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Set the link value as per the issue
            if (lblTitle05.Text.StartsWith(Globals.strTitleText01))
                Process.Start(Globals.strLinkRam);
            else if (lblTitle05.Text.StartsWith(Globals.strTitleText02))
                Process.Start(Globals.strLinkHDSpace);
            else if (lblTitle05.Text.Equals(Globals.strTitleText03))
                Process.Start(Globals.strLinkWiFi);
            else if (lblTitle05.Text.Equals(Globals.strTitleText04))
                Process.Start(Globals.strLinkOpenedCentralModel);
            else if (lblTitle05.Text.Equals(Globals.strTitleText05))
                Process.Start(Globals.strLinkUsersInModel);
            else if (lblTitle05.Text.Equals(Globals.strTitleText06))
                Process.Start(Globals.strLinkOpenedOverWAN);
            else
                Process.Start(Globals.strLinkElse);
        }

        private void lblLinkLabel06_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Set the link value as per the issue
            if (lblTitle06.Text.StartsWith(Globals.strTitleText01))
                Process.Start(Globals.strLinkRam);
            else if (lblTitle06.Text.StartsWith(Globals.strTitleText02))
                Process.Start(Globals.strLinkHDSpace);
            else if (lblTitle06.Text.Equals(Globals.strTitleText03))
                Process.Start(Globals.strLinkWiFi);
            else if (lblTitle06.Text.Equals(Globals.strTitleText04))
                Process.Start(Globals.strLinkOpenedCentralModel);
            else if (lblTitle06.Text.Equals(Globals.strTitleText05))
                Process.Start(Globals.strLinkUsersInModel);
            else if (lblTitle06.Text.Equals(Globals.strTitleText06))
                Process.Start(Globals.strLinkOpenedOverWAN);
            else
                Process.Start(Globals.strLinkElse);
        }
    }
}
