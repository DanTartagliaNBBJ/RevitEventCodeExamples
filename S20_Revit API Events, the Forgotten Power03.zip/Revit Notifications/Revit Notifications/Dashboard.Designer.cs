﻿namespace RevitNotifications
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.pbxOrange01 = new System.Windows.Forms.PictureBox();
            this.pbxGreen01 = new System.Windows.Forms.PictureBox();
            this.pbxRed01 = new System.Windows.Forms.PictureBox();
            this.lblTitle01 = new System.Windows.Forms.Label();
            this.lblLink01 = new System.Windows.Forms.Label();
            this.lblValue01 = new System.Windows.Forms.Label();
            this.pbxOrange02 = new System.Windows.Forms.PictureBox();
            this.lblLink02 = new System.Windows.Forms.Label();
            this.lblTitle02 = new System.Windows.Forms.Label();
            this.lblValue02 = new System.Windows.Forms.Label();
            this.pbxOrange03 = new System.Windows.Forms.PictureBox();
            this.lblLink03 = new System.Windows.Forms.Label();
            this.lblTitle03 = new System.Windows.Forms.Label();
            this.lblValue03 = new System.Windows.Forms.Label();
            this.lblValue04 = new System.Windows.Forms.Label();
            this.pbxOrange05 = new System.Windows.Forms.PictureBox();
            this.lblValue05 = new System.Windows.Forms.Label();
            this.lblLink05 = new System.Windows.Forms.Label();
            this.lblTitle05 = new System.Windows.Forms.Label();
            this.pbxOrange04 = new System.Windows.Forms.PictureBox();
            this.lblLink04 = new System.Windows.Forms.Label();
            this.lblTitle04 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.pbxRed05 = new System.Windows.Forms.PictureBox();
            this.pbxRed04 = new System.Windows.Forms.PictureBox();
            this.pbxRed03 = new System.Windows.Forms.PictureBox();
            this.pbxRed02 = new System.Windows.Forms.PictureBox();
            this.pbxGreen05 = new System.Windows.Forms.PictureBox();
            this.pbxGreen04 = new System.Windows.Forms.PictureBox();
            this.pbxGreen03 = new System.Windows.Forms.PictureBox();
            this.pbxGreen02 = new System.Windows.Forms.PictureBox();
            this.lblFileName = new System.Windows.Forms.Label();
            this.lblLinkLabel01 = new System.Windows.Forms.LinkLabel();
            this.lblLinkLabel02 = new System.Windows.Forms.LinkLabel();
            this.lblLinkLabel03 = new System.Windows.Forms.LinkLabel();
            this.lblLinkLabel04 = new System.Windows.Forms.LinkLabel();
            this.lblLinkLabel05 = new System.Windows.Forms.LinkLabel();
            this.lblVersion = new System.Windows.Forms.Label();
            this.lblLinkLabel06 = new System.Windows.Forms.LinkLabel();
            this.pbxGreen06 = new System.Windows.Forms.PictureBox();
            this.pbxRed06 = new System.Windows.Forms.PictureBox();
            this.lblLink06 = new System.Windows.Forms.Label();
            this.lblTitle06 = new System.Windows.Forms.Label();
            this.lblValue06 = new System.Windows.Forms.Label();
            this.pbxOrange06 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxOrange01
            // 
            this.pbxOrange01.Image = ((System.Drawing.Image)(resources.GetObject("pbxOrange01.Image")));
            this.pbxOrange01.Location = new System.Drawing.Point(157, 31);
            this.pbxOrange01.Name = "pbxOrange01";
            this.pbxOrange01.Size = new System.Drawing.Size(35, 37);
            this.pbxOrange01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxOrange01.TabIndex = 189;
            this.pbxOrange01.TabStop = false;
            this.pbxOrange01.Visible = false;
            // 
            // pbxGreen01
            // 
            this.pbxGreen01.Image = ((System.Drawing.Image)(resources.GetObject("pbxGreen01.Image")));
            this.pbxGreen01.Location = new System.Drawing.Point(157, 31);
            this.pbxGreen01.Name = "pbxGreen01";
            this.pbxGreen01.Size = new System.Drawing.Size(35, 37);
            this.pbxGreen01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxGreen01.TabIndex = 190;
            this.pbxGreen01.TabStop = false;
            this.pbxGreen01.Visible = false;
            // 
            // pbxRed01
            // 
            this.pbxRed01.Image = ((System.Drawing.Image)(resources.GetObject("pbxRed01.Image")));
            this.pbxRed01.Location = new System.Drawing.Point(157, 31);
            this.pbxRed01.Name = "pbxRed01";
            this.pbxRed01.Size = new System.Drawing.Size(35, 37);
            this.pbxRed01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxRed01.TabIndex = 191;
            this.pbxRed01.TabStop = false;
            this.pbxRed01.Visible = false;
            // 
            // lblTitle01
            // 
            this.lblTitle01.AutoSize = true;
            this.lblTitle01.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle01.Location = new System.Drawing.Point(199, 31);
            this.lblTitle01.Name = "lblTitle01";
            this.lblTitle01.Size = new System.Drawing.Size(0, 24);
            this.lblTitle01.TabIndex = 0;
            // 
            // lblLink01
            // 
            this.lblLink01.AutoSize = true;
            this.lblLink01.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLink01.Location = new System.Drawing.Point(200, 78);
            this.lblLink01.Name = "lblLink01";
            this.lblLink01.Size = new System.Drawing.Size(144, 16);
            this.lblLink01.TabIndex = 1;
            this.lblLink01.Text = "For more info and help:";
            // 
            // lblValue01
            // 
            this.lblValue01.AutoSize = true;
            this.lblValue01.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValue01.Location = new System.Drawing.Point(199, 55);
            this.lblValue01.Name = "lblValue01";
            this.lblValue01.Size = new System.Drawing.Size(0, 20);
            this.lblValue01.TabIndex = 4;
            // 
            // pbxOrange02
            // 
            this.pbxOrange02.Image = ((System.Drawing.Image)(resources.GetObject("pbxOrange02.Image")));
            this.pbxOrange02.Location = new System.Drawing.Point(157, 119);
            this.pbxOrange02.Name = "pbxOrange02";
            this.pbxOrange02.Size = new System.Drawing.Size(35, 37);
            this.pbxOrange02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxOrange02.TabIndex = 194;
            this.pbxOrange02.TabStop = false;
            this.pbxOrange02.Visible = false;
            // 
            // lblLink02
            // 
            this.lblLink02.AutoSize = true;
            this.lblLink02.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLink02.Location = new System.Drawing.Point(200, 166);
            this.lblLink02.Name = "lblLink02";
            this.lblLink02.Size = new System.Drawing.Size(144, 16);
            this.lblLink02.TabIndex = 191;
            this.lblLink02.Text = "For more info and help:";
            // 
            // lblTitle02
            // 
            this.lblTitle02.AutoSize = true;
            this.lblTitle02.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle02.Location = new System.Drawing.Point(199, 119);
            this.lblTitle02.Name = "lblTitle02";
            this.lblTitle02.Size = new System.Drawing.Size(0, 24);
            this.lblTitle02.TabIndex = 190;
            // 
            // lblValue02
            // 
            this.lblValue02.AutoSize = true;
            this.lblValue02.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValue02.Location = new System.Drawing.Point(199, 143);
            this.lblValue02.Name = "lblValue02";
            this.lblValue02.Size = new System.Drawing.Size(0, 20);
            this.lblValue02.TabIndex = 195;
            // 
            // pbxOrange03
            // 
            this.pbxOrange03.Image = ((System.Drawing.Image)(resources.GetObject("pbxOrange03.Image")));
            this.pbxOrange03.Location = new System.Drawing.Point(157, 207);
            this.pbxOrange03.Name = "pbxOrange03";
            this.pbxOrange03.Size = new System.Drawing.Size(35, 37);
            this.pbxOrange03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxOrange03.TabIndex = 200;
            this.pbxOrange03.TabStop = false;
            this.pbxOrange03.Visible = false;
            // 
            // lblLink03
            // 
            this.lblLink03.AutoSize = true;
            this.lblLink03.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLink03.Location = new System.Drawing.Point(200, 254);
            this.lblLink03.Name = "lblLink03";
            this.lblLink03.Size = new System.Drawing.Size(144, 16);
            this.lblLink03.TabIndex = 197;
            this.lblLink03.Text = "For more info and help:";
            // 
            // lblTitle03
            // 
            this.lblTitle03.AutoSize = true;
            this.lblTitle03.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle03.Location = new System.Drawing.Point(199, 207);
            this.lblTitle03.Name = "lblTitle03";
            this.lblTitle03.Size = new System.Drawing.Size(0, 24);
            this.lblTitle03.TabIndex = 196;
            // 
            // lblValue03
            // 
            this.lblValue03.AutoSize = true;
            this.lblValue03.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValue03.Location = new System.Drawing.Point(199, 231);
            this.lblValue03.Name = "lblValue03";
            this.lblValue03.Size = new System.Drawing.Size(0, 20);
            this.lblValue03.TabIndex = 201;
            // 
            // lblValue04
            // 
            this.lblValue04.AutoSize = true;
            this.lblValue04.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValue04.Location = new System.Drawing.Point(199, 320);
            this.lblValue04.Name = "lblValue04";
            this.lblValue04.Size = new System.Drawing.Size(0, 20);
            this.lblValue04.TabIndex = 3;
            // 
            // pbxOrange05
            // 
            this.pbxOrange05.Image = ((System.Drawing.Image)(resources.GetObject("pbxOrange05.Image")));
            this.pbxOrange05.Location = new System.Drawing.Point(157, 384);
            this.pbxOrange05.Name = "pbxOrange05";
            this.pbxOrange05.Size = new System.Drawing.Size(35, 37);
            this.pbxOrange05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxOrange05.TabIndex = 194;
            this.pbxOrange05.TabStop = false;
            this.pbxOrange05.Visible = false;
            // 
            // lblValue05
            // 
            this.lblValue05.AutoSize = true;
            this.lblValue05.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValue05.Location = new System.Drawing.Point(199, 408);
            this.lblValue05.Name = "lblValue05";
            this.lblValue05.Size = new System.Drawing.Size(0, 20);
            this.lblValue05.TabIndex = 193;
            // 
            // lblLink05
            // 
            this.lblLink05.AutoSize = true;
            this.lblLink05.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLink05.Location = new System.Drawing.Point(200, 431);
            this.lblLink05.Name = "lblLink05";
            this.lblLink05.Size = new System.Drawing.Size(144, 16);
            this.lblLink05.TabIndex = 191;
            this.lblLink05.Text = "For more info and help:";
            // 
            // lblTitle05
            // 
            this.lblTitle05.AutoSize = true;
            this.lblTitle05.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle05.Location = new System.Drawing.Point(199, 384);
            this.lblTitle05.Name = "lblTitle05";
            this.lblTitle05.Size = new System.Drawing.Size(0, 24);
            this.lblTitle05.TabIndex = 190;
            // 
            // pbxOrange04
            // 
            this.pbxOrange04.Image = ((System.Drawing.Image)(resources.GetObject("pbxOrange04.Image")));
            this.pbxOrange04.Location = new System.Drawing.Point(157, 296);
            this.pbxOrange04.Name = "pbxOrange04";
            this.pbxOrange04.Size = new System.Drawing.Size(35, 37);
            this.pbxOrange04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxOrange04.TabIndex = 189;
            this.pbxOrange04.TabStop = false;
            this.pbxOrange04.Visible = false;
            // 
            // lblLink04
            // 
            this.lblLink04.AutoSize = true;
            this.lblLink04.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLink04.Location = new System.Drawing.Point(200, 343);
            this.lblLink04.Name = "lblLink04";
            this.lblLink04.Size = new System.Drawing.Size(144, 16);
            this.lblLink04.TabIndex = 1;
            this.lblLink04.Text = "For more info and help:";
            // 
            // lblTitle04
            // 
            this.lblTitle04.AutoSize = true;
            this.lblTitle04.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle04.Location = new System.Drawing.Point(199, 296);
            this.lblTitle04.Name = "lblTitle04";
            this.lblTitle04.Size = new System.Drawing.Size(0, 24);
            this.lblTitle04.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClose.Location = new System.Drawing.Point(270, 622);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 203;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pbxRed05
            // 
            this.pbxRed05.Image = ((System.Drawing.Image)(resources.GetObject("pbxRed05.Image")));
            this.pbxRed05.Location = new System.Drawing.Point(157, 384);
            this.pbxRed05.Name = "pbxRed05";
            this.pbxRed05.Size = new System.Drawing.Size(35, 37);
            this.pbxRed05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxRed05.TabIndex = 205;
            this.pbxRed05.TabStop = false;
            this.pbxRed05.Visible = false;
            // 
            // pbxRed04
            // 
            this.pbxRed04.Image = ((System.Drawing.Image)(resources.GetObject("pbxRed04.Image")));
            this.pbxRed04.Location = new System.Drawing.Point(157, 296);
            this.pbxRed04.Name = "pbxRed04";
            this.pbxRed04.Size = new System.Drawing.Size(35, 37);
            this.pbxRed04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxRed04.TabIndex = 206;
            this.pbxRed04.TabStop = false;
            this.pbxRed04.Visible = false;
            // 
            // pbxRed03
            // 
            this.pbxRed03.Image = ((System.Drawing.Image)(resources.GetObject("pbxRed03.Image")));
            this.pbxRed03.Location = new System.Drawing.Point(157, 207);
            this.pbxRed03.Name = "pbxRed03";
            this.pbxRed03.Size = new System.Drawing.Size(35, 37);
            this.pbxRed03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxRed03.TabIndex = 207;
            this.pbxRed03.TabStop = false;
            this.pbxRed03.Visible = false;
            // 
            // pbxRed02
            // 
            this.pbxRed02.Image = ((System.Drawing.Image)(resources.GetObject("pbxRed02.Image")));
            this.pbxRed02.Location = new System.Drawing.Point(157, 119);
            this.pbxRed02.Name = "pbxRed02";
            this.pbxRed02.Size = new System.Drawing.Size(35, 37);
            this.pbxRed02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxRed02.TabIndex = 208;
            this.pbxRed02.TabStop = false;
            this.pbxRed02.Visible = false;
            // 
            // pbxGreen05
            // 
            this.pbxGreen05.Image = ((System.Drawing.Image)(resources.GetObject("pbxGreen05.Image")));
            this.pbxGreen05.Location = new System.Drawing.Point(157, 384);
            this.pbxGreen05.Name = "pbxGreen05";
            this.pbxGreen05.Size = new System.Drawing.Size(35, 37);
            this.pbxGreen05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxGreen05.TabIndex = 210;
            this.pbxGreen05.TabStop = false;
            this.pbxGreen05.Visible = false;
            // 
            // pbxGreen04
            // 
            this.pbxGreen04.Image = ((System.Drawing.Image)(resources.GetObject("pbxGreen04.Image")));
            this.pbxGreen04.Location = new System.Drawing.Point(157, 296);
            this.pbxGreen04.Name = "pbxGreen04";
            this.pbxGreen04.Size = new System.Drawing.Size(35, 37);
            this.pbxGreen04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxGreen04.TabIndex = 211;
            this.pbxGreen04.TabStop = false;
            this.pbxGreen04.Visible = false;
            // 
            // pbxGreen03
            // 
            this.pbxGreen03.Image = ((System.Drawing.Image)(resources.GetObject("pbxGreen03.Image")));
            this.pbxGreen03.Location = new System.Drawing.Point(157, 207);
            this.pbxGreen03.Name = "pbxGreen03";
            this.pbxGreen03.Size = new System.Drawing.Size(35, 37);
            this.pbxGreen03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxGreen03.TabIndex = 212;
            this.pbxGreen03.TabStop = false;
            this.pbxGreen03.Visible = false;
            // 
            // pbxGreen02
            // 
            this.pbxGreen02.Image = ((System.Drawing.Image)(resources.GetObject("pbxGreen02.Image")));
            this.pbxGreen02.Location = new System.Drawing.Point(157, 119);
            this.pbxGreen02.Name = "pbxGreen02";
            this.pbxGreen02.Size = new System.Drawing.Size(35, 37);
            this.pbxGreen02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxGreen02.TabIndex = 213;
            this.pbxGreen02.TabStop = false;
            this.pbxGreen02.Visible = false;
            // 
            // lblFileName
            // 
            this.lblFileName.AutoSize = true;
            this.lblFileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileName.Location = new System.Drawing.Point(156, 7);
            this.lblFileName.Name = "lblFileName";
            this.lblFileName.Size = new System.Drawing.Size(52, 12);
            this.lblFileName.TabIndex = 223;
            this.lblFileName.Text = "<file name>";
            // 
            // lblLinkLabel01
            // 
            this.lblLinkLabel01.AutoSize = true;
            this.lblLinkLabel01.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLinkLabel01.Location = new System.Drawing.Point(341, 78);
            this.lblLinkLabel01.Name = "lblLinkLabel01";
            this.lblLinkLabel01.Size = new System.Drawing.Size(32, 16);
            this.lblLinkLabel01.TabIndex = 224;
            this.lblLinkLabel01.TabStop = true;
            this.lblLinkLabel01.Text = "Link";
            this.lblLinkLabel01.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLinkLabel01_LinkClicked);
            // 
            // lblLinkLabel02
            // 
            this.lblLinkLabel02.AutoSize = true;
            this.lblLinkLabel02.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLinkLabel02.Location = new System.Drawing.Point(341, 166);
            this.lblLinkLabel02.Name = "lblLinkLabel02";
            this.lblLinkLabel02.Size = new System.Drawing.Size(32, 16);
            this.lblLinkLabel02.TabIndex = 225;
            this.lblLinkLabel02.TabStop = true;
            this.lblLinkLabel02.Text = "Link";
            this.lblLinkLabel02.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLinkLabel02_LinkClicked);
            // 
            // lblLinkLabel03
            // 
            this.lblLinkLabel03.AutoSize = true;
            this.lblLinkLabel03.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLinkLabel03.Location = new System.Drawing.Point(341, 254);
            this.lblLinkLabel03.Name = "lblLinkLabel03";
            this.lblLinkLabel03.Size = new System.Drawing.Size(32, 16);
            this.lblLinkLabel03.TabIndex = 226;
            this.lblLinkLabel03.TabStop = true;
            this.lblLinkLabel03.Text = "Link";
            this.lblLinkLabel03.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLinkLabel03_LinkClicked);
            // 
            // lblLinkLabel04
            // 
            this.lblLinkLabel04.AutoSize = true;
            this.lblLinkLabel04.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLinkLabel04.Location = new System.Drawing.Point(341, 343);
            this.lblLinkLabel04.Name = "lblLinkLabel04";
            this.lblLinkLabel04.Size = new System.Drawing.Size(32, 16);
            this.lblLinkLabel04.TabIndex = 227;
            this.lblLinkLabel04.TabStop = true;
            this.lblLinkLabel04.Text = "Link";
            this.lblLinkLabel04.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLinkLabel04_LinkClicked);
            // 
            // lblLinkLabel05
            // 
            this.lblLinkLabel05.AutoSize = true;
            this.lblLinkLabel05.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLinkLabel05.Location = new System.Drawing.Point(341, 431);
            this.lblLinkLabel05.Name = "lblLinkLabel05";
            this.lblLinkLabel05.Size = new System.Drawing.Size(32, 16);
            this.lblLinkLabel05.TabIndex = 228;
            this.lblLinkLabel05.TabStop = true;
            this.lblLinkLabel05.Text = "Link";
            this.lblLinkLabel05.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLinkLabel05_LinkClicked);
            // 
            // lblVersion
            // 
            this.lblVersion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.Location = new System.Drawing.Point(564, 633);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(40, 13);
            this.lblVersion.TabIndex = 230;
            this.lblVersion.Text = "1.0.0.0";
            // 
            // lblLinkLabel06
            // 
            this.lblLinkLabel06.AutoSize = true;
            this.lblLinkLabel06.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLinkLabel06.Location = new System.Drawing.Point(341, 519);
            this.lblLinkLabel06.Name = "lblLinkLabel06";
            this.lblLinkLabel06.Size = new System.Drawing.Size(32, 16);
            this.lblLinkLabel06.TabIndex = 240;
            this.lblLinkLabel06.TabStop = true;
            this.lblLinkLabel06.Text = "Link";
            this.lblLinkLabel06.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLinkLabel06_LinkClicked);
            // 
            // pbxGreen06
            // 
            this.pbxGreen06.Image = ((System.Drawing.Image)(resources.GetObject("pbxGreen06.Image")));
            this.pbxGreen06.Location = new System.Drawing.Point(157, 472);
            this.pbxGreen06.Name = "pbxGreen06";
            this.pbxGreen06.Size = new System.Drawing.Size(35, 37);
            this.pbxGreen06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxGreen06.TabIndex = 239;
            this.pbxGreen06.TabStop = false;
            this.pbxGreen06.Visible = false;
            // 
            // pbxRed06
            // 
            this.pbxRed06.Image = ((System.Drawing.Image)(resources.GetObject("pbxRed06.Image")));
            this.pbxRed06.Location = new System.Drawing.Point(157, 472);
            this.pbxRed06.Name = "pbxRed06";
            this.pbxRed06.Size = new System.Drawing.Size(35, 37);
            this.pbxRed06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxRed06.TabIndex = 238;
            this.pbxRed06.TabStop = false;
            this.pbxRed06.Visible = false;
            // 
            // lblLink06
            // 
            this.lblLink06.AutoSize = true;
            this.lblLink06.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLink06.Location = new System.Drawing.Point(200, 519);
            this.lblLink06.Name = "lblLink06";
            this.lblLink06.Size = new System.Drawing.Size(144, 16);
            this.lblLink06.TabIndex = 235;
            this.lblLink06.Text = "For more info and help:";
            // 
            // lblTitle06
            // 
            this.lblTitle06.AutoSize = true;
            this.lblTitle06.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle06.Location = new System.Drawing.Point(199, 472);
            this.lblTitle06.Name = "lblTitle06";
            this.lblTitle06.Size = new System.Drawing.Size(0, 24);
            this.lblTitle06.TabIndex = 234;
            // 
            // lblValue06
            // 
            this.lblValue06.AutoSize = true;
            this.lblValue06.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValue06.Location = new System.Drawing.Point(199, 496);
            this.lblValue06.Name = "lblValue06";
            this.lblValue06.Size = new System.Drawing.Size(0, 20);
            this.lblValue06.TabIndex = 236;
            // 
            // pbxOrange06
            // 
            this.pbxOrange06.Image = ((System.Drawing.Image)(resources.GetObject("pbxOrange06.Image")));
            this.pbxOrange06.Location = new System.Drawing.Point(157, 472);
            this.pbxOrange06.Name = "pbxOrange06";
            this.pbxOrange06.Size = new System.Drawing.Size(35, 37);
            this.pbxOrange06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxOrange06.TabIndex = 237;
            this.pbxOrange06.TabStop = false;
            this.pbxOrange06.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(5, -1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(126, 43);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 233;
            this.pictureBox2.TabStop = false;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(616, 658);
            this.Controls.Add(this.lblLinkLabel06);
            this.Controls.Add(this.lblLink06);
            this.Controls.Add(this.lblTitle06);
            this.Controls.Add(this.lblValue06);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.lblLinkLabel05);
            this.Controls.Add(this.lblLinkLabel04);
            this.Controls.Add(this.lblLinkLabel03);
            this.Controls.Add(this.lblLinkLabel02);
            this.Controls.Add(this.lblLinkLabel01);
            this.Controls.Add(this.lblFileName);
            this.Controls.Add(this.pbxGreen02);
            this.Controls.Add(this.pbxGreen03);
            this.Controls.Add(this.pbxGreen04);
            this.Controls.Add(this.pbxRed02);
            this.Controls.Add(this.pbxRed03);
            this.Controls.Add(this.pbxRed04);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblValue03);
            this.Controls.Add(this.pbxGreen01);
            this.Controls.Add(this.lblTitle01);
            this.Controls.Add(this.lblLink01);
            this.Controls.Add(this.pbxOrange03);
            this.Controls.Add(this.lblLink05);
            this.Controls.Add(this.lblValue01);
            this.Controls.Add(this.pbxRed01);
            this.Controls.Add(this.lblTitle05);
            this.Controls.Add(this.lblLink03);
            this.Controls.Add(this.pbxOrange01);
            this.Controls.Add(this.lblValue05);
            this.Controls.Add(this.lblTitle03);
            this.Controls.Add(this.lblTitle02);
            this.Controls.Add(this.lblTitle04);
            this.Controls.Add(this.pbxOrange04);
            this.Controls.Add(this.lblValue04);
            this.Controls.Add(this.lblLink02);
            this.Controls.Add(this.lblValue02);
            this.Controls.Add(this.lblLink04);
            this.Controls.Add(this.pbxOrange02);
            this.Controls.Add(this.pbxGreen06);
            this.Controls.Add(this.pbxGreen05);
            this.Controls.Add(this.pbxRed05);
            this.Controls.Add(this.pbxRed06);
            this.Controls.Add(this.pbxOrange05);
            this.Controls.Add(this.pbxOrange06);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Revit Performance Dashboard";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Dashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOrange06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pbxOrange01;
        private System.Windows.Forms.PictureBox pbxGreen01;
        private System.Windows.Forms.PictureBox pbxRed01;
        private System.Windows.Forms.Label lblTitle01;
        private System.Windows.Forms.PictureBox pbxOrange02;
        private System.Windows.Forms.Label lblLink02;
        private System.Windows.Forms.Label lblTitle02;
        private System.Windows.Forms.Label lblValue01;
        private System.Windows.Forms.Label lblLink01;
        private System.Windows.Forms.Label lblValue03;
        private System.Windows.Forms.PictureBox pbxOrange03;
        private System.Windows.Forms.Label lblLink03;
        private System.Windows.Forms.Label lblTitle03;
        private System.Windows.Forms.Label lblValue02;
        private System.Windows.Forms.Label lblValue04;
        private System.Windows.Forms.PictureBox pbxOrange05;
        private System.Windows.Forms.Label lblValue05;
        private System.Windows.Forms.Label lblLink05;
        private System.Windows.Forms.Label lblTitle05;
        private System.Windows.Forms.PictureBox pbxOrange04;
        private System.Windows.Forms.Label lblLink04;
        private System.Windows.Forms.Label lblTitle04;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.PictureBox pbxRed05;
        private System.Windows.Forms.PictureBox pbxRed04;
        private System.Windows.Forms.PictureBox pbxRed03;
        private System.Windows.Forms.PictureBox pbxRed02;
        private System.Windows.Forms.PictureBox pbxGreen05;
        private System.Windows.Forms.PictureBox pbxGreen04;
        private System.Windows.Forms.PictureBox pbxGreen03;
        private System.Windows.Forms.PictureBox pbxGreen02;
        private System.Windows.Forms.Label lblFileName;
        private System.Windows.Forms.LinkLabel lblLinkLabel01;
        private System.Windows.Forms.LinkLabel lblLinkLabel02;
        private System.Windows.Forms.LinkLabel lblLinkLabel03;
        private System.Windows.Forms.LinkLabel lblLinkLabel04;
        private System.Windows.Forms.LinkLabel lblLinkLabel05;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.LinkLabel lblLinkLabel06;
        private System.Windows.Forms.PictureBox pbxGreen06;
        private System.Windows.Forms.PictureBox pbxRed06;
        private System.Windows.Forms.Label lblLink06;
        private System.Windows.Forms.Label lblTitle06;
        private System.Windows.Forms.Label lblValue06;
        private System.Windows.Forms.PictureBox pbxOrange06;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}