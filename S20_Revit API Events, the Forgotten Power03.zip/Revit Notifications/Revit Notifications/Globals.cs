﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitNotifications
{
    class Globals
    {
        public static string strAppVersion = "1.0.0.8";

        private bool _blnIsIssueRed = false;
        private bool _blnRAMAvailFlag = false;
        private bool _blnRAMAvailRed = false;

        public static string strErrorLogFileName = "RevitNotificationsErrorLog.csv";
        public static string strErrorLogPath = @"C:\Users\dtartaglia\Documents\Dans-stuff\Conferences\Digital Built Week\2019\Revit API Events\Examples\Revit Notifications\Errors\";

        public static string strCSVLogFileName = "RevitNotifications.csv";                
        public static string strCSVLogFilePath = @"C:\Users\dtartaglia\Documents\Dans-stuff\Conferences\Digital Built Week\2019\Revit API Events\Examples\Revit Notifications\";

        public static string strEnvVarUserName = "USERNAME";
        public static string strEnvVarLoginServer = "LOGONSERVER";
        public static string strEnvVarComputerName = "COMPUTERNAME";

        ////// Test values
        ////public static double dblMinimumRAMValue = 45;
        ////public static double dblMaximumRAMValue = 60;
        ////public static double dblMinimumHDValue = 30;
        ////public static double dblMaximumHDValue = 100;
        ////public static int intMinimumUserValue = -1;
        ////public static int intMaximumUserValue = 3;

        //==============================================================
        // DocumentOpening event values
        //==============================================================
        // Below 4 GBs of available RAM causes a red flag
        public static double dblMinimumOpeningRAMValue = 4;        

        // Between 4-8 GBs of available RAM causes a orange flag
        public static double dblMaximumOpeningRAMValue = 8;        

        // Below 12.5 GBs of hd space causes a red flag
        public static double dblMinimumOpeningHDValue = 12.5;
        
        // Between 12.5-25 GBs of hd space causes a orange flag
        public static double dblMaximumOpeningHDValue = 25;        

        //==============================================================
        // DocumentOpened event values
        //==============================================================
        // Below 1 GBs of available RAM causes a red flag
        public static double dblMinimumRAMValue = 1;        

        // Between 1-2 GBs of available RAM causes a orange flag
        public static double dblMaximumRAMValue = 2;        

        // Below 4 GBs of hd space causes a red flag
        public static double dblMinimumHDValue = 4;        

        // Between 4-8 GBs of hd space causes a orange flag
        public static double dblMaximumHDValue = 8;        

        // Between 8-12 users in the model causes a orange flag
        public static int intMinimumUserValue = 8;

        // Above 12 users in the model causes a red flag
        public static int intMaximumUserValue = 12;
        //==============================================================

        public static string strTitleText01 = "Available RAM";
        public static string strTitleText02 = "Free Hard Drive Space";
        public static string strTitleText03 = "Wi-Fi Enabled?";        
        public static string strTitleText04 = "Opened Central File?";
        public static string strTitleText05 = "Users in the Model";
        public static string strTitleText06 = "Opened over WAN";

        public static string strC4RAppendedValue01 = "A360:";
        public static string strC4RAppendedValue02 = "BIM 360:";
        public static string strRSAppendedValue03 = "RSN:";

        public static string strLinkRam = "http://digitalpractice/revit-performance-issue-not-enough-available-ram/";
        public static string strLinkHDSpace = "http://digitalpractice/revit-performance-issue-not-enough-free-hard-drive-space/";
        public static string strLinkWiFi = "http://digitalpractice/revit-performance-issue-wi-fi-enabled/";        
        public static string strLinkUsersInModel = "http://digitalpractice/revit-performance-issue-number-of-users-in-model/";
        public static string strLinkOpenedCentralModel = "http://digitalpractice/revit-performance-issue-opened-central-file/";
        public static string strLinkOpenedOverWAN = "http://nbbjdigital/revit-performance-issue-opened-file-over-wan/";
        public static string strLinkElse = "http://nbbjdigital/revit-performance-issue/";

        public static string strXMLFileName = "RevitNotificationsAlert.xml";
        public static string strXMLFileFullPath = @"C:\Users\dtartaglia\Documents\Dans-stuff\Conferences\Digital Built Week\2019\Revit API Events\Examples\Revit Notifications\" + strXMLFileName;

        public static string strEmailSubject = "Revit Performance Issue Detected - ";        

        private bool _blnHDSpaceFreeFlag = false;
        private bool _blnHDSpaceFreeRed = false;
        private bool _blnWiFiEnabledFlag = false;
        private bool _blnCentralFileOpenFlag = false;
        private bool _blnUsersInModelFlag = false;
        private bool _blnUsersInModelRed = false;
        private bool _blnWorkingOverWANFlag = false;

        private string _strTitleValue01 = string.Empty;
        private string _strTitleValue02 = string.Empty;
        private string _strTitleValue03 = string.Empty;
        private string _strTitleValue04 = string.Empty;
        private string _strTitleValue05 = string.Empty;
        private string _strTitleValue06 = string.Empty;

        private string _strValue01 = string.Empty;
        private string _strValue02 = string.Empty;
        private string _strValue03 = string.Empty;
        private string _strValue04 = string.Empty;
        private string _strValue05 = string.Empty;
        private string _strValue06 = string.Empty;

        private string _strLinkValue01 = string.Empty;
        private string _strLinkValue02 = string.Empty;
        private string _strLinkValue03 = string.Empty;
        private string _strLinkValue04 = string.Empty;
        private string _strLinkValue05 = string.Empty;
        private string _strLinkValue06 = string.Empty;

        private string _strRAMMessage = string.Empty;
        private string _strFreeHDMessage = string.Empty;
        private string _strWiFiMessage = string.Empty;
        private string _strOpenCentralFileMessage = string.Empty;
        private string _strUsersInModelMessage = string.Empty;
        private string _strWorkingOverWANOfficeAbbrev = string.Empty;

        private string _strUserName = string.Empty;
        private string _strUserStudioCode = string.Empty;
        private List<string> _lstBIMLeadData = new List<string>();
        private List<string> _lstEmailAddresses = new List<string>();

        public bool blnIsIssueRed
        {
            get { return _blnIsIssueRed; }
            set { _blnIsIssueRed = value; }
        }

        public bool blnRAMAvailFlag
        {
            get { return _blnRAMAvailFlag; }
            set { _blnRAMAvailFlag = value; }
        }
        public bool blnRAMAvailRed
        {
            get { return _blnRAMAvailRed; }
            set { _blnRAMAvailRed = value; }
        }

        public bool blnHDSpaceFreeFlag
        {
            get { return _blnHDSpaceFreeFlag; }
            set { _blnHDSpaceFreeFlag = value; }
        }

        public bool blnHDSpaceFreeRed
        {
            get { return _blnHDSpaceFreeRed; }
            set { _blnHDSpaceFreeRed = value; }
        }

        public bool blnWiFiEnabledFlag
        {
            get { return _blnWiFiEnabledFlag; }
            set { _blnWiFiEnabledFlag = value; }
        }

        public bool blnCentralFileOpenFlag
        {
            get { return _blnCentralFileOpenFlag; }
            set { _blnCentralFileOpenFlag = value; }
        }

        public bool blnUsersInModelFlag
        {
            get { return _blnUsersInModelFlag; }
            set { _blnUsersInModelFlag = value; }
        }

        public bool blnUsersInModelRed
        {
            get { return _blnUsersInModelRed; }
            set { _blnUsersInModelRed = value; }
        }

        public bool blnWorkingOverWANFlag
        {
            get { return _blnWorkingOverWANFlag; }
            set { _blnWorkingOverWANFlag = value; }
        }

        public string strTitleValue01
        {
            get { return _strTitleValue01; }
            set { _strTitleValue01 = value; }
        }

        public string strTitleValue02
        {
            get { return _strTitleValue02; }
            set { _strTitleValue02 = value; }
        }

        public string strTitleValue03
        {
            get { return _strTitleValue03; }
            set { _strTitleValue03 = value; }
        }

        public string strTitleValue04
        {
            get { return _strTitleValue04; }
            set { _strTitleValue04 = value; }
        }

        public string strTitleValue05
        {
            get { return _strTitleValue05; }
            set { _strTitleValue05 = value; }
        }

        public string strTitleValue06
        {
            get { return _strTitleValue06; }
            set { _strTitleValue06 = value; }
        }

        public string strValue01
        {
            get { return _strValue01; }
            set { _strValue01 = value; }
        }

        public string strValue02
        {
            get { return _strValue02; }
            set { _strValue02 = value; }
        }
        public string strValue03
        {
            get { return _strValue03; }
            set { _strValue03 = value; }
        }
        public string strValue04
        {
            get { return _strValue04; }
            set { _strValue04 = value; }
        }
        public string strValue05
        {
            get { return _strValue05; }
            set { _strValue05 = value; }
        }

        public string strValue06
        {
            get { return _strValue06; }
            set { _strValue06 = value; }
        }

        public string strLinkValue01
        {
            get { return _strLinkValue01; }
            set { _strLinkValue01 = value; }
        }
        public string strLinkValue02
        {
            get { return _strLinkValue02; }
            set { _strLinkValue02 = value; }
        }
        public string strLinkValue03
        {
            get { return _strLinkValue03; }
            set { _strLinkValue03 = value; }
        }
        public string strLinkValue04
        {
            get { return _strLinkValue04; }
            set { _strLinkValue04 = value; }
        }
        public string strLinkValue05
        {
            get { return _strLinkValue05; }
            set { _strLinkValue05 = value; }
        }

        public string strLinkValue06
        {
            get { return _strLinkValue06; }
            set { _strLinkValue06 = value; }
        }

        public string strRAMMessage
        {
            get { return _strRAMMessage; }
            set { _strRAMMessage = value; }
        }

        public string strFreeHDMessage
        {
            get { return _strFreeHDMessage; }
            set { _strFreeHDMessage = value; }
        }

        public string strWiFiMessage
        {
            get { return _strWiFiMessage; }
            set { _strWiFiMessage = value; }
        }

        public string strOpenCentralFileMessage
        {
            get { return _strOpenCentralFileMessage; }
            set { _strOpenCentralFileMessage = value; }
        }

        public string strUsersInModelMessage
        {
            get { return _strUsersInModelMessage; }
            set { _strUsersInModelMessage = value; }
        }

        public string strWorkingOverWANOfficeAbbrev
        {
            get { return _strWorkingOverWANOfficeAbbrev; }
            set { _strWorkingOverWANOfficeAbbrev = value; }
        }
        
        public string strUserName
        {
            get { return _strUserName; }
            set { _strUserName = value; }
        }

        public string strUserStudioCode
        {
            get { return _strUserStudioCode; }
            set { _strUserStudioCode = value; }
        }

        public List<string> lstBIMLeadData
        {
            get { return _lstBIMLeadData; }
            set { _lstBIMLeadData = value; }
        }

        public List<string> lstEmailAddresses
        {
            get { return _lstEmailAddresses; }
            set { _lstEmailAddresses = value; }
        }

        public static List<string> FirmOfficeAbbrevsGet()
        {
            List<string> lstOfficeAbbrevs = new List<string>();

            lstOfficeAbbrevs.Add("COL-");
            lstOfficeAbbrevs.Add("CMH-");
            return lstOfficeAbbrevs;
        }
    }
}
