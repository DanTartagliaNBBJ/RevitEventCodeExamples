﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;
using System.Diagnostics;
using System.Xml;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace RevitNotifications
{
    class IssuesFind
    {
        public static Globals oGlobals = new Globals();

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Start of issues process
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void BeginIssuesProcess(Document oDocument)
        {
            if (IssuesProcessModelOpened(oDocument) == true)
            {
                // Get the active user's studio code from Outlook (Department)
                oGlobals.strUserStudioCode = StudioCodeOutlookGet();

                if (oGlobals.strUserStudioCode.Equals(string.Empty))
                    // Get Computer Logon Office abbreviation
                    oGlobals.strUserStudioCode = LogonOfficeGet(Environment.GetEnvironmentVariable(Globals.strEnvVarLoginServer));

                oGlobals.strUserName = UserNameOutlookGet();

                if (oGlobals.strUserName.Equals(string.Empty))
                    oGlobals.strUserName = Environment.GetEnvironmentVariable(Globals.strEnvVarUserName);

                if (!oGlobals.strUserStudioCode.Equals(string.Empty))
                {
                    CSVFileWrite.CSVFileWriteProcess(oGlobals);

                    // Extract all the BIM Lead data from the XML file
                    oGlobals.lstBIMLeadData = BIMLeadDataExtract();

                    if (oGlobals.lstBIMLeadData.Count > 0)
                    {
                        // Keep processing only if Outlook is running
                        if (ProcessExist("OUTLOOK") == true)
                        {
                            // Main email process
                            Email.EmailProcess(oGlobals);
                        }
                    }
            }
                // Display the ballon tip and icon
                BalloonTipLogic.BalloonTipDisplay();
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determine if a given Window's process is currently running
        /// </summary>
        /// <returns> bool </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static bool ProcessExist(string strProcessName)
        {
            // Get the processes
            Process[] processlist = Process.GetProcesses();

            // Iterate through each process
            foreach (Process theprocess in processlist)
            {
                // Look for the wanted process name
                if (theprocess.ProcessName.ToUpper() == strProcessName)
                    return true;
            }
            return false;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the active user's studio code from Outlook (Department)
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string StudioCodeOutlookGet()
        {
            try
            {
                // Get Outlook object
                Outlook.Application oOutlookApp = new Outlook.Application();
                Outlook.ExchangeUser oCurrentUser = 
                    oOutlookApp.Session.CurrentUser.AddressEntry.GetExchangeUser();

                return oCurrentUser.Department;
            }
            catch
            {
                return string.Empty;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the active user's name from Outlook
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string UserNameOutlookGet()
        {
            try
            {
                // Get Outlook object
                Outlook.Application oOutlookApp = new Outlook.Application();
                Outlook.ExchangeUser oCurrentUser = 
                    oOutlookApp.Session.CurrentUser.AddressEntry.GetExchangeUser();

                return oCurrentUser.Name;
            }
            catch
            {
                return string.Empty;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Extract all the BIM Lead data from the XML file
        /// </summary>
        /// <returns> List<string> </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static List<string> BIMLeadDataExtract()
        {
            string strUserData = string.Empty;
            List<string> lstTemp = new List<string>();
            oGlobals.lstBIMLeadData = new List<string>();
            try
            {
                // Open the XML file
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(Globals.strXMLFileFullPath);

                // Set the node to search for
                XmlNodeList memberNodes = xmlDoc.SelectNodes("//" + "Users");

                // Iterate through each node
                foreach (XmlNode node in memberNodes)
                {
                    // Iterate through each child node
                    foreach (XmlNode childNodes in node)
                    {
                        strUserData = childNodes.Name;

                        // Iterate through each sub child node
                        foreach (XmlNode subChildNodes in childNodes)
                        {
                            strUserData += " " + subChildNodes.InnerText;
                        }
                        lstTemp.Add(strUserData);
                    }
                }
            }
            catch
            {
                lstTemp = new List<string>();
                return lstTemp;
            }
            return lstTemp;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Process each of the 1 computer related issue
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>01/2018</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void IssuesProcessModelOpening()
        {
            oGlobals.strRAMMessage = string.Empty;
            oGlobals.strFreeHDMessage = string.Empty;
            oGlobals.blnIsIssueRed = false;

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Avaiable RAM
            /*--------------+---------------+---------------+---------------+---------------+------*/
            try
            {
                oGlobals.blnRAMAvailFlag = false;
                oGlobals.blnRAMAvailRed = false;
                oGlobals.blnHDSpaceFreeFlag = false;
                oGlobals.blnHDSpaceFreeRed = false;

                // Determine if there is enough available RAM
                if (GetAvailMemoryInBytes() < Globals.dblMaximumOpeningRAMValue)
                {
                    // Determine if this is a red or orange issue
                    if (GetAvailMemoryInBytes() < Globals.dblMinimumOpeningRAMValue)
                    {
                        oGlobals.blnRAMAvailRed = true;
                        oGlobals.blnIsIssueRed = true;
                    }
                    else
                        oGlobals.blnRAMAvailRed = false;

                    // Set the flag
                    oGlobals.blnRAMAvailFlag = true;

                    oGlobals.strTitleValue01 = Globals.strTitleText01 + " (pre-model open)";
                    oGlobals.strValue01 = GetAvailMemoryInBytes().ToString() + " GBs";
                    oGlobals.strLinkValue01 = "For more info and help:";
                }
                else
                    // Set the flag
                    oGlobals.blnRAMAvailFlag = false;
            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, Globals.strTitleText01);
                MessageBox.Show(ex.Message);
            }
            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Free Hard Drive Space
            /*--------------+---------------+---------------+---------------+---------------+------*/
            try
            {
                double test = FreeHardDriveSpace("C");

                // Determine if there is enough free hard drive space
                if (FreeHardDriveSpace("C") < Globals.dblMaximumOpeningHDValue)
                {
                    // Determine if this is a red or orange issue
                    if (FreeHardDriveSpace("C") < Globals.dblMinimumOpeningHDValue)
                    {
                        oGlobals.blnHDSpaceFreeRed = true;
                        oGlobals.blnIsIssueRed = true;
                    }
                    else
                        oGlobals.blnHDSpaceFreeRed = false;

                    // Set the flag
                    oGlobals.blnHDSpaceFreeFlag = true;

                    oGlobals.strTitleValue02 = Globals.strTitleText02 + " (pre-model open)";
                    oGlobals.strValue02 = FreeHardDriveSpace("C").ToString() + " GBs";
                    oGlobals.strLinkValue02 = "For more info and help:";
                }
                else
                    // Set the flag
                    oGlobals.blnHDSpaceFreeFlag = false;
            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, Globals.strTitleText02);
                MessageBox.Show(ex.Message);
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Process each of the 6 issues
        /// </summary>
        /// <returns> bool </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static bool IssuesProcessModelOpened(Document oDocument)
        {
            oGlobals.strWiFiMessage = string.Empty;            
            oGlobals.strOpenCentralFileMessage = string.Empty;
            oGlobals.strUsersInModelMessage = string.Empty;

            // Get the ModelPath of the document if worksharing is enabled
            ModelPath oModelPath = WSModelPathGet(oDocument);

            // Get the string of the path of a given ModelPath (central file)
            string strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Avaiable RAM
            /*--------------+---------------+---------------+---------------+---------------+------*/
            try
            {
                // Determine if there is enough available RAM
                if (GetAvailMemoryInBytes() < Globals.dblMaximumRAMValue)
                {
                    // Determine if this is a red or orange issue
                    if (GetAvailMemoryInBytes() < Globals.dblMinimumRAMValue)
                    {
                        oGlobals.blnRAMAvailRed = true;
                        oGlobals.blnIsIssueRed = true;
                    }
                    else
                        oGlobals.blnRAMAvailRed = false;

                    // Set the flag
                    oGlobals.blnRAMAvailFlag = true;

                    oGlobals.strTitleValue01 = Globals.strTitleText01;
                    oGlobals.strValue01 = GetAvailMemoryInBytes().ToString() + " GBs";
                    oGlobals.strLinkValue01 = "For more info and help:";
                }
            }
            catch(Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, Globals.strTitleText01);

                MessageBox.Show(ex.Message);
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Free Hard Drive Space
            /*--------------+---------------+---------------+---------------+---------------+------*/
            try
            {
                // Determine if there is enough free hard drive space
                if (FreeHardDriveSpace("C") < Globals.dblMaximumHDValue)
                {
                    // Determine if this is a red or orange issue
                    if (FreeHardDriveSpace("C") < Globals.dblMinimumHDValue)
                    {
                        oGlobals.blnHDSpaceFreeRed = true;
                        oGlobals.blnIsIssueRed = true;
                    }
                    else
                        oGlobals.blnHDSpaceFreeRed = false;

                    // Set the flag
                    oGlobals.blnHDSpaceFreeFlag = true;

                    oGlobals.strTitleValue02 = Globals.strTitleText02;
                    oGlobals.strValue02 = FreeHardDriveSpace("C").ToString() + " GBs";
                    oGlobals.strLinkValue02 = "For more info and help:";
                }

            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, Globals.strTitleText02);

                MessageBox.Show(ex.Message);
                return false;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Wi-Fi enabled
            /*--------------+---------------+---------------+---------------+---------------+------*/
            try
            {
                // Skip C4R and Revit Server files
                if (!strFullPath.StartsWith(Globals.strC4RAppendedValue01) &&
                !strFullPath.StartsWith(Globals.strC4RAppendedValue02) &&
                !strFullPath.StartsWith(Globals.strRSAppendedValue03))
                {
                    // Determine if wireless is enabled
                    if (IsWirelessEnabled() == true)
                    {
                        //// Determine if ethernet is enabled
                        //if (IsEthernetEnabled() == true)
                        //    // Set the flag
                        //    oGlobals.blnWiFiEnabledFlag = false;
                        //else
                        //{
                            // Set the flag
                            oGlobals.blnWiFiEnabledFlag = true;

                            oGlobals.strTitleValue03 = Globals.strTitleText03;
                            oGlobals.strValue03 = "Yes";
                            oGlobals.strLinkValue03 = "For more info and help:";
                            oGlobals.blnIsIssueRed = true;
                        //}
                    }
                    else
                        // Set the flag
                        oGlobals.blnWiFiEnabledFlag = false;
                }
                else
                    // Set the flag
                    oGlobals.blnWiFiEnabledFlag = false;

            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, Globals.strTitleText03);

                MessageBox.Show(ex.Message);
                return false;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// User have Central file open
            /*--------------+---------------+---------------+---------------+---------------+------*/
            try
            {
                // Skip C4R files
                if (!strFullPath.StartsWith(Globals.strC4RAppendedValue01) &&
                    !strFullPath.StartsWith(Globals.strC4RAppendedValue02))
                {
                    // Determine the central file is open
                    if (RevitDetermineIfCentral(oModelPath, oDocument).Equals("True"))
                    {
                        // Set the flag
                        oGlobals.blnCentralFileOpenFlag = true;

                        oGlobals.strTitleValue04 = Globals.strTitleText04;
                        oGlobals.strValue04 = "Yes";
                        oGlobals.strLinkValue04 = "For more info and help:";
                        oGlobals.blnIsIssueRed = true;
                    }
                    else
                        // Set the flag
                        oGlobals.blnCentralFileOpenFlag = false;
                }
                else
                    // Set the flag
                    oGlobals.blnCentralFileOpenFlag = false;
            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, Globals.strTitleText04);

                MessageBox.Show(ex.Message);
                return false;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Users in the Model
            /*--------------+---------------+---------------+---------------+---------------+------*/
            try
            {
                // Get number of users in the current model
                int intConcurrentUsers = ConcurrentUsersGet(RevitFileCentralFullPathGet(oModelPath, oDocument));

                // Determine if more people are in the model than should be
                if (intConcurrentUsers > Globals.intMinimumUserValue)
                {
                    if (intConcurrentUsers > Globals.intMaximumUserValue)
                    {
                        oGlobals.blnUsersInModelRed = true;
                        oGlobals.blnIsIssueRed = true;
                    }                        
                    else
                        oGlobals.blnUsersInModelRed = false;

                    // Set the flag
                    oGlobals.blnUsersInModelFlag = true;

                    oGlobals.strTitleValue05 = Globals.strTitleText05;
                    oGlobals.strValue05 = intConcurrentUsers.ToString() + " Users";
                    oGlobals.strLinkValue05 = "For more info and help:";
                }
                else
                    // Set the flag
                    oGlobals.blnUsersInModelFlag = false;
            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, Globals.strTitleText05);

                MessageBox.Show(ex.Message);
                return false;
            }

            /*------------------------------------------------------------------------------------**/
            /// <summary>
            /// Users working over WAN
            /*--------------+---------------+---------------+---------------+---------------+------*/
            try
            {
                // Skip C4R and Revit Server files
                if (!strFullPath.StartsWith(Globals.strC4RAppendedValue01) &&
                !strFullPath.StartsWith(Globals.strC4RAppendedValue02) &&
                !strFullPath.StartsWith(Globals.strRSAppendedValue03))
                {
                    // Get Computer Logon Office abbreviation
                    string strLoginOfficeValue = LogonOfficeGet(Environment.GetEnvironmentVariable(Globals.strEnvVarLoginServer));

                    // Do not continue unless both variables have a value
                    if (strFullPath == null || strFullPath.Equals("") || strLoginOfficeValue.Equals(""))
                        // Set the flag
                        oGlobals.blnWorkingOverWANFlag = false;
                    else
                    {
                        // Determine if user is working over the WAN
                        if (WorkingOverWAN(strLoginOfficeValue, strFullPath, oDocument) == true)
                        {
                            // Set the flag
                            oGlobals.blnWorkingOverWANFlag = true;

                            oGlobals.strTitleValue06 = Globals.strTitleText06;

                            if (oGlobals.strWorkingOverWANOfficeAbbrev.Equals(string.Empty))
                                oGlobals.strWorkingOverWANOfficeAbbrev = "UNKNOWN";

                            oGlobals.strValue06 = "Yes" + " (" + strLoginOfficeValue + " to " + oGlobals.strWorkingOverWANOfficeAbbrev + ")";

                            oGlobals.strLinkValue06 = "For more info and help:";
                            oGlobals.blnIsIssueRed = true;
                        }
                        else
                            // Set the flag
                            oGlobals.blnWorkingOverWANFlag = false;
                    }
                }
                else
                    // Set the flag
                    oGlobals.blnWorkingOverWANFlag = false;
            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, Globals.strTitleText06);

                MessageBox.Show(ex.Message);
                return false;
            }

            // Return true if any issue is found
            if (oGlobals.blnRAMAvailFlag == true || oGlobals.blnHDSpaceFreeFlag == true ||
                oGlobals.blnWiFiEnabledFlag == true || oGlobals.blnCentralFileOpenFlag == true || 
                oGlobals.blnUsersInModelFlag || oGlobals.blnWorkingOverWANFlag == true)
                return true;
            else
                return false;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Write to the error log
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void ErrorLogProcess(string strErrorMsg, string strMessage)
        {
            // Create the folder if needed
            if (!Directory.Exists(Globals.strErrorLogPath))
                Directory.CreateDirectory(Globals.strErrorLogPath);

            // Add headers if needed
            if (!File.Exists(Globals.strErrorLogPath + Globals.strErrorLogFileName))
                // Write to the error file
                TextFileWrite(Globals.strErrorLogPath + Globals.strErrorLogFileName, 
                    "Date,User Name,Computer Name,Error Message,Function", true);

            // Create output string
            string strError = DateTime.Now.ToString() + "," + Environment.GetEnvironmentVariable("USERNAME") + "," 
                + Environment.GetEnvironmentVariable("COMPUTERNAME") + "," + strErrorMsg + "," + strMessage;

            // Write to the error file
            TextFileWrite(Globals.strErrorLogPath + Globals.strErrorLogFileName, strError, true);
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Write to the output text file
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>01/2013</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void TextFileWrite(string strTextFileName, string strValue, bool blnAppend)
        {
            try
            {
                // create a writer and open the file
                TextWriter tw = new StreamWriter(strTextFileName, blnAppend);

                // Add a line of text to the output file
                tw.WriteLine(strValue);

                // close the stream
                tw.Close();
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get Available Physical Memory
        /// </summary>
        /// <returns> ulong </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static double GetAvailMemoryInBytes()
        {
            try
            {
                ulong ulgTemp = new Microsoft.VisualBasic.Devices.ComputerInfo().AvailablePhysicalMemory;
                double dblTemp = Convert.ToDouble(ulgTemp);
                return Math.Round(((dblTemp) / (1024 * 1024) / 1024), 2);                
            }
            catch(Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, "GetAvailMemoryInBytes");

                return -1;
            }            
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get a hard drive's free space
        /// </summary>
        /// <returns> double </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2010</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static double FreeHardDriveSpace(string strDriveLetter)
        {
            try
            {
                // Get the free hard drive space
                long lngFreeSpace = GetTotalFreeSpace(strDriveLetter + ":\\");

                if (lngFreeSpace == -1)
                {
                    return -1;
                }
                else
                {
                    int byteConversion = 1024;
                    double dblFreeSpace = Convert.ToDouble(lngFreeSpace);
                    return Math.Round(dblFreeSpace / Math.Pow(byteConversion, 3), 2);
                }
            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, "FreeHardDriveSpace");

                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get a hard drive's free space
        /// </summary>
        /// <returns> long </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2010</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private static long GetTotalFreeSpace(string driveName)
        {
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady && drive.Name.ToUpper() == driveName.ToUpper())
                {
                    return drive.TotalFreeSpace;
                }
            }
            return -1;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Deterime if wireless is enabled or not on the computer
        /// </summary>
        /// <returns> bool </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static bool IsWirelessEnabled()
        {
            NetworkInterface[] networkCards = NetworkInterface.GetAllNetworkInterfaces();

            // Iterate through each
            foreach (NetworkInterface nc in networkCards)
            {
                if (nc.NetworkInterfaceType == NetworkInterfaceType.Wireless80211)
                {
                    if (nc.OperationalStatus == OperationalStatus.Up)
                        return true;
                }
            }
            return false;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the file size
        /// </summary>
        /// <returns> double </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static double FileSizeGet(string strFilePathName)
        {
            try
            {
                FileInfo fInfo = new FileInfo(strFilePathName);
                return Math.Round((Convert.ToDouble(fInfo.Length / 1024) / 1024),2);
            }
            catch(Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, "FileSizeGet");

                return 0;
            }
        }
        
        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determine if a RVT is a central file or local file (should be easier in newer versions)
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string RevitDetermineIfCentral(ModelPath oModelPath, Document oDoc)
        {
            string strFullPath = string.Empty;

            try
            {
                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null)
                        return "";

                    if (strFullPath.Equals(""))
                        return "";

                    // Remove the 1st 3 chars from the opening file path
                    string strPartialOpenPath = oDoc.PathName.Substring(3, oDoc.PathName.Length - 3);

                    // Determine if the opening file path exists in the central file path
                    int intResult = IsStringFound(strPartialOpenPath, strFullPath);

                    if (intResult >= 0 || oDoc.PathName.Equals(strFullPath))
                        return "True";
                    else
                        return "False";
                }
                else
                    return "";
            }
            catch(Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, "RevitDetermineIfCentral");

                return "";
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determine if user is working over the WAN
        /// </summary>
        /// <returns> bool </returns>
        /// <author>Dan.Tartaglia </author>                              <date>12/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static bool WorkingOverWAN(string strLoginOfficeValue, string strFullPath, Document oDoc)
        {
            try
            {
                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    string strTemp = string.Empty;

                    // Get the Computer Name
                    string strComputerName = LogonOfficeGet(Environment.GetEnvironmentVariable(Globals.strEnvVarComputerName));
                    
                    // Break the path into an array
                    string[] strValues = strFullPath.Split('\\');

                    // Iterate through each value
                    foreach (string strValue in strValues)
                    {
                        // Only process values with 5 chars (i.e. SEAHC)
                        if (strValue.Length == 5)
                        {
                            // Attempt to get the office abbreviation from the model
                            strTemp = ModelOfficeGet(strValue.Substring(0, 3));

                            if (!strTemp.Equals(string.Empty))
                                oGlobals.strWorkingOverWANOfficeAbbrev = strTemp;

                            // If values match, you are not working over WAN
                            if (strLoginOfficeValue == strValue.Substring(0, 3))
                                return false;

                            // Columbus abbreviations
                            if ((strLoginOfficeValue == "CMH" && strValue.Substring(0, 3) == "COL") ||
                                (strLoginOfficeValue == "COL" && strValue.Substring(0, 3) == "CMH"))
                                return false;

                            // Hong Kong abbreviations
                            if ((strLoginOfficeValue == "HKG" && strValue.Substring(0, 3) == "SHA") ||
                                (strLoginOfficeValue == "SHA" && strValue.Substring(0, 3) == "HKG"))
                                return false;

                            // Seattle abbreviations
                            if (strLoginOfficeValue == "TUK" && strValue.Substring(0, 3) == "SEA")
                                return false;
                        }
                    }

                    // Return false if no studio abbrev found
                    if (oGlobals.strWorkingOverWANOfficeAbbrev.Equals(string.Empty))
                        return false;

                    // (05-17-18) Determine if user computer name has same office code as project
                    if (!strComputerName.Equals(string.Empty))
                    {
                        if (ComputerNameIsInPath(strComputerName, strValues) == true)
                            return false;
                    }

                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, "WorkingOverWAN");

                return false;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// (05-17-18) Determine if user computer name has same office code as project
        /// </summary>
        /// <returns> bool </returns>
        /// <author>Dan.Tartaglia </author>                              <date>05/2018</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static bool ComputerNameIsInPath(string strComputerName, string[] strValues)
        {
            try
            {
                // Iterate through each value
                foreach (string strValue in strValues)
                {
                    // Only process values with 5 chars (i.e. SEAHC)
                    if (strValue.Length == 5)
                    {
                        if (strComputerName.Equals(strValue.Substring(0, 3), StringComparison.OrdinalIgnoreCase))
                            return true;
                    }
                }

                return false;
            }
            catch
            {
                return true;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determines if one string is within the other
        /// </summary>
        /// <returns> int </returns>
        /// <author>Dan.Tartaglia </author>                              <date>01/2010</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static int IsStringFound(String strValue, String strPath)
        {
            return (strPath.IndexOf(strValue));
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the ModelPath object for workshared models
        /// </summary>
        /// <returns> ModelPath </returns>
        /// <author>Dan.Tartaglia </author>                              <date>05/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static ModelPath WSModelPathGet(Document oDoc)
        {
            try
            {
                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)

                    // Get the ModelPath object
                    return oDoc.GetWorksharingCentralModelPath();
            }
            catch(Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, "WSModelPathGet");

                return null;
            }
            return null;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get central file path
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string RevitFileCentralFullPathGet(ModelPath oModelPath, Document oDoc)
        {
            string strFullPath = string.Empty;

            try
            {
                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null)
                        return "";

                    if (strFullPath.Equals(""))
                        return "";

                    return strFullPath;
                }
                else
                {
                    // Handle non-workshared files                    
                    strFullPath = oDoc.PathName;

                    if (strFullPath == null)
                        return "";

                    if (strFullPath.Equals(""))
                        return "";

                    return strFullPath;
                }
            }
            catch(Exception ex)
            {
                // Write error message
                ErrorLogProcess(ex.Message, "RevitFileCentralFullPathGet");

                return "";
            }            
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get number of users in the current model
        /// </summary>
        /// <returns> int </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static int ConcurrentUsersGet(string strFullPath)
        { 
            return 1;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the office code the user is currently working in
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>12/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string LogonOfficeGet(string strEnvVarLoginServer)
        {
            try
            {
                List<string> lstOfficeAbbrevs = Globals.FirmOfficeAbbrevsGet();                

                // Iterate the studio abbrevs
                foreach (string strOfficeAbbrev in lstOfficeAbbrevs)
                {
                    // Determine if the studio abbrev is in the string
                    if (IsStringFound(strOfficeAbbrev.ToUpper(), strEnvVarLoginServer.ToUpper()) > -1)
                        return strOfficeAbbrev.Substring(0,3);
                }
            }
            catch
            {
                return string.Empty;
            }
            return string.Empty;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the office code the model currently working in
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>12/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string ModelOfficeGet(string strValue)
        {
            try
            {
                List<string> lstOfficeAbbrevs = Globals.FirmOfficeAbbrevsGet();

                // Iterate the studio abbrevs
                foreach (string strOfficeAbbrev in lstOfficeAbbrevs)
                {
                    // Determine if the studio abbrev is in the string
                    if (strValue == strOfficeAbbrev.Substring(0, 3))
                        return strOfficeAbbrev.Substring(0, 3);
                }
            }
            catch
            {
                return string.Empty;
            }
            return string.Empty;
        }
    }
}
