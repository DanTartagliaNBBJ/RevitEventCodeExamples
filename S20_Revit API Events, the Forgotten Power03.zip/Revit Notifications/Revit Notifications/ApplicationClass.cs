﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;

namespace RevitNotifications
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class ApplicationClass : IExternalApplication
    {
         // Public variable
        public static Autodesk.Revit.DB.Document m_RevitDocument;

        // Implement OnStartup method of IExternalApplication interface.
        public Autodesk.Revit.UI.Result OnStartup(UIControlledApplication application)
        {
            // Intiate the events
            application.ControlledApplication.DocumentOpening += new EventHandler<DocumentOpeningEventArgs>(DocumentOpeningEvent);
            application.ControlledApplication.DocumentOpened += new EventHandler<DocumentOpenedEventArgs>(DocumentOpenedEvent);
            application.ControlledApplication.DocumentClosing += new EventHandler<DocumentClosingEventArgs>(DocumentClosingEvent);

            return Autodesk.Revit.UI.Result.Succeeded;
        }

        // Implement OnShutdown method of IExternalApplication interface. 
        public Autodesk.Revit.UI.Result OnShutdown(UIControlledApplication application)
        {
            application.ControlledApplication.DocumentOpening -= new EventHandler<DocumentOpeningEventArgs>(DocumentOpeningEvent);
            application.ControlledApplication.DocumentOpened -= new EventHandler<DocumentOpenedEventArgs>(DocumentOpenedEvent);
            application.ControlledApplication.DocumentClosing -= new EventHandler<DocumentClosingEventArgs>(DocumentClosingEvent);

            // Remove the notification icon
            BalloonTipLogic.NotificationRemove();

            return Autodesk.Revit.UI.Result.Succeeded;
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentOpening event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentOpeningEvent(Object sender, DocumentOpeningEventArgs args)
        {
            IssuesFind.IssuesProcessModelOpening();
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentOpened event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentOpenedEvent(Object sender, DocumentOpenedEventArgs args)
        {
            // Remove the notification icon
            BalloonTipLogic.NotificationRemove();

            // Only process workshared RVTs
            if (args.Document.IsWorkshared == false)
                return;

            // Get the ModelPath of the document if worksharing is enabled
            ModelPath oModelPath = IssuesFind.WSModelPathGet(args.Document);

            // Skip detached models
            if (RevitDetermineIfDetached(oModelPath, args.Document) == true)
                return;

            // Get the active document
            m_RevitDocument = args.Document;

            // Begin the process to looking for issues
            IssuesFind.BeginIssuesProcess(args.Document);
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentClosing event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentClosingEvent(Object sender, DocumentClosingEventArgs args)
        {
            // Remove the notification icon
            BalloonTipLogic.NotificationRemove();
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determine if a RVT is detached
        /// </summary>
        /// <returns> bool </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static bool RevitDetermineIfDetached(ModelPath oModelPath, Document oDoc)
        {
            string strFullPath = string.Empty;

            try
            {
                // Verify the document is found
                if (oDoc == null)
                    return false;

                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null || strFullPath.Equals(string.Empty))
                        return true;

                    // Determine if the 'rvt' extension is found
                    if (Path.GetExtension(strFullPath).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase))
                        return false;
                }
                else
                    // non-workshared file
                    return false;
            }
            catch
            {
                return false;
            }
            return false;
        }
    }
}
