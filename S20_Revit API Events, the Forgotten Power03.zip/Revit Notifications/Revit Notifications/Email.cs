﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace RevitNotifications
{
    class Email
    {
        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Start the email process
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void EmailProcess(Globals oGlobals)
        {
            oGlobals.lstEmailAddresses = new List<string>();

            try
            {
                if (oGlobals.blnIsIssueRed == false)
                    return;

                // Available RAM
                if (oGlobals.blnRAMAvailFlag == true)
                {
                    // Get email addresses that want notification 
                    List<string> lstIssue01 = EmailAddressesGet(18, oGlobals);

                    // Add all email addresses to one list
                    oGlobals.lstEmailAddresses.AddRange(lstIssue01);
                }

                // Free HD space
                if (oGlobals.blnHDSpaceFreeFlag == true)
                {
                    // Get email addresses that want notification 
                    List<string> lstIssue02 = EmailAddressesGet(19, oGlobals);

                    // Add all email addresses to one list
                    oGlobals.lstEmailAddresses.AddRange(lstIssue02);
                }

                // Wi-Fi enabled
                if (oGlobals.blnWiFiEnabledFlag == true)
                {
                    // Get email addresses that want notification 
                    List<string> lstIssue03 = EmailAddressesGet(20, oGlobals);

                    // Add all email addresses to one list
                    oGlobals.lstEmailAddresses.AddRange(lstIssue03);
                }

                // Open central file
                if (oGlobals.blnCentralFileOpenFlag == true)
                {
                    // Get email addresses that want notification 
                    List<string> lstIssue04 = EmailAddressesGet(21, oGlobals);

                    // Add all email addresses to one list
                    oGlobals.lstEmailAddresses.AddRange(lstIssue04);
                }

                // Users in the model
                if (oGlobals.blnUsersInModelFlag == true)
                {
                    // Get email addresses that want notification 
                    List<string> lstIssue05 = EmailAddressesGet(22, oGlobals);

                    // Add all email addresses to one list
                    oGlobals.lstEmailAddresses.AddRange(lstIssue05);
                }

                // User working over WAN
                if (oGlobals.blnWorkingOverWANFlag == true)
                {
                    // Get email addresses that want notification 
                    List<string> lstIssue06 = EmailAddressesGet(23, oGlobals);

                    // Add all email addresses to one list
                    oGlobals.lstEmailAddresses.AddRange(lstIssue06);
                }

                // Remove duplicates
                oGlobals.lstEmailAddresses = oGlobals.lstEmailAddresses.Distinct().ToList();

                // Keep processing if we have email addresses
                if (oGlobals.lstEmailAddresses.Count > 0)
                    // Send the emails
                    EmailsSendProcess(oGlobals);
            }
            catch
            {

            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the email addresses for each BIM Lead to contact
        /// </summary>
        /// <returns> List<string> </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static List<string> EmailAddressesGet(int intValue, Globals oGlobals)
        {
            List<string> lstTemp = new List<string>();
            lstTemp.Add("dtartaglia@nbbj.com");
            return lstTemp;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Create and send the emails
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void EmailsSendProcess(Globals oGlobals)
        {
            string strEmailBody = string.Empty;
            string strIssueStatus = string.Empty;

            try
            {
                // Stop if no emails are found
                if (oGlobals.lstEmailAddresses.Count == 0)
                    return;

                // Get Outlook object
                Outlook.Application oOutlookApp = new Outlook.Application();
                Outlook.MailItem oMail = oOutlookApp.CreateItem(Outlook.OlItemType.olMailItem) as Outlook.MailItem;

                // Set the status
                if (IssuesFind.oGlobals.blnRAMAvailRed == true || IssuesFind.oGlobals.blnHDSpaceFreeRed == true ||
                    IssuesFind.oGlobals.blnWiFiEnabledFlag == true || IssuesFind.oGlobals.blnCentralFileOpenFlag == true || 
                    IssuesFind.oGlobals.blnUsersInModelRed == true || IssuesFind.oGlobals.blnWorkingOverWANFlag == true)

                    strIssueStatus = " - Status: Red";
                else
                    strIssueStatus = " - Status: Orange";

                // Set the Subject                
                oMail.Subject = Globals.strEmailSubject + oGlobals.strUserName + " - " 
                    + oGlobals.strUserStudioCode + strIssueStatus;

                // Set the priority
                oMail.Importance = Outlook.OlImportance.olImportanceHigh;

                // Add each primary email address
                foreach (string strValue in oGlobals.lstEmailAddresses)
                {
                    oMail.Recipients.Add(strValue);
                }

                // Verify they are valid
                oMail.Recipients.ResolveAll();

                // Date and time
                strEmailBody = "<b>Date/Time:</b><br>" + DateTimeCurrentGet() + "</br>";

                // User name
                strEmailBody += "<br><br><b>User Name:</b></br></br><br>" + oGlobals.strUserName + "</br>";

                // Computer name
                strEmailBody += "<br><br><b>Computer Name:</b></br></br><br>" + EnvironmentVariableGet("COMPUTERNAME") + "</br>";

                try
                {
                    // Revit version/build
                    strEmailBody += "<br><br><b>Revit Version/Build:</b></br></br><br>" +
                        ApplicationClass.m_RevitDocument.Application.VersionName + " / " +
                        ApplicationClass.m_RevitDocument.Application.VersionBuild + "</br>";
                }
                catch
                {
                }

                // Get the ModelPath of the document if worksharing is enabled
                ModelPath oModelPath = IssuesFind.WSModelPathGet(ApplicationClass.m_RevitDocument);

                // Central file full path
                if (oModelPath != null)
                    strEmailBody += "<br><br><b>Central File Full Path:</b></br></br><br>" + 
                        RevitFilePathValueGet(oModelPath, ApplicationClass.m_RevitDocument) + "</br>";

                // Title for issues
                strEmailBody += "<br><br><b>Issue(s) Found:</b></br></br>";

                // Available RAM
                if (oGlobals.blnRAMAvailFlag == true)
                {
                    if (oGlobals.blnRAMAvailRed == true)
                        strEmailBody += "<br><br><b>Red:</b></br></br>";
                    else
                        strEmailBody += "<br><br><b>Orange:</b></br></br>";

                    strEmailBody += "<br>" + oGlobals.strTitleValue01 + "</br>";
                    strEmailBody += "<br>" + oGlobals.strValue01 + "</br>";
                }

                // Free HD space
                if (oGlobals.blnHDSpaceFreeFlag == true)
                {
                    if (oGlobals.blnHDSpaceFreeRed == true)
                        strEmailBody += "<br><br><b>Red:</b></br></br>";
                    else
                        strEmailBody += "<br><br><b>Orange:</b></br></br>";

                    strEmailBody += "<br>" + oGlobals.strTitleValue02 + "</br>";
                    strEmailBody += "<br>" + oGlobals.strValue02 + "</br>";
                }

                // Wi-Fi enabled?
                if (oGlobals.blnWiFiEnabledFlag == true)
                {
                    strEmailBody += "<br><br><b>Red:</b></br></br>";

                    strEmailBody += "<br>" + oGlobals.strTitleValue03 + "</br>";
                    strEmailBody += "<br>" + oGlobals.strValue03 + "</br>";
                }

                // Opened central file?
                if (oGlobals.blnCentralFileOpenFlag == true)
                {
                    strEmailBody += "<br><br><b>Red:</b></br></br>";

                    strEmailBody += "<br>" + oGlobals.strTitleValue04 + "</br>";
                    strEmailBody += "<br>" + oGlobals.strValue04 + "</br>";
                }

                // Users in the model
                if (oGlobals.blnUsersInModelFlag == true)
                {
                    if (oGlobals.blnUsersInModelRed == true)
                        strEmailBody += "<br><br><b>Red:</b></br></br>";
                    else
                        strEmailBody += "<br><br><b>Orange:</b></br></br>";

                    strEmailBody += "<br>" + oGlobals.strTitleValue05 + "</br>";
                    strEmailBody += "<br>" + oGlobals.strValue05 + "</br>";
                }

                // User working over WAN
                if (oGlobals.blnWorkingOverWANFlag == true)
                {
                    strEmailBody += "<br><br><b>Red:</b></br></br>";

                    strEmailBody += "<br>" + oGlobals.strTitleValue06 + "</br>";
                    strEmailBody += "<br>" + oGlobals.strValue06 + "</br>";
                }

                strEmailBody += "<br><br>Application Version: " + Globals.strAppVersion + "</br></br>";

                oMail.HTMLBody = strEmailBody;

                // Send the email
                ////oMail.Display();
                oMail.Send();

            }
            catch
            {

            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get Environment Variable value
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>09/2012</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string EnvironmentVariableGet(string strVarName)
        {
            // Get the environment variable value
            return Environment.GetEnvironmentVariable(strVarName);
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get central file path
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string RevitFilePathValueGet(ModelPath oModelPath, Document oDoc)
        {            
            string strFullPath = string.Empty;

            try
            {
                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null)
                        return string.Empty;

                    if (strFullPath.Equals(""))
                        return string.Empty;

                    return strFullPath; 
                }
                else
                {
                    // Handle non-workshared files                    
                    strFullPath = oDoc.PathName;

                    if (strFullPath == null)
                        return "";

                    if (strFullPath.Equals(""))
                        return "";

                    return strFullPath;
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the current date and time
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>05/2017</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string DateTimeCurrentGet()
        {
            try
            {
                var oCulture = new CultureInfo("en-US");

                DateTime localDate = DateTime.Now;
                return localDate.ToString(oCulture);
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
