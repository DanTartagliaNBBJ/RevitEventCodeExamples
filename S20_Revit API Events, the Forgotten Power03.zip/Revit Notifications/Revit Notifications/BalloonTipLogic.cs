﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace RevitNotifications
{
    class BalloonTipLogic
    {
        // Public variable
        public static NotifyIcon oNotifyIcon = null;

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Display the balloon tip
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void BalloonTipDisplay()
        {        
            try
            {
                // Remove the message/icon if displaying
                NotificationRemove();

                // Gets the full path for the EXE
                string strIcon = Path.GetDirectoryName(typeof(ApplicationClass).Assembly.Location) + "\\" + "ND.ico";

                string strIconMessage = "Revit Performance Issues Found. Click for more information";
                string strTitle = "Revit Performance Issues Found";
                string strMessage = "Please click this message or the 'nd' icon for more information";

                // Remove the message/icon if displaying
                NotificationRemove();

                // Create/setup the NotifyIcon
                oNotifyIcon = new NotifyIcon();

                // Do not display if the image is not found
                if (File.Exists(strIcon) == false)
                    return;

                // Display an image in the Notification area
                oNotifyIcon.Icon = new Icon(strIcon);

                // Message hovering over icon
                oNotifyIcon.Text = strIconMessage;

                // Initialize MouseClick event 
                oNotifyIcon.MouseClick += new MouseEventHandler(NotifyIcon_MouseClick);

                // Initialize BalloonTipClicked event 
                oNotifyIcon.BalloonTipClicked += new EventHandler(NotifyIcon_BalloonTipClicked);

                // Initialize BalloonTipClosed event 
                //oNotifyIcon.BalloonTipClosed += new EventHandler(NotifyIcon_BalloonTipClosed);

                // Show icon
                oNotifyIcon.Visible = true;

                if (IssuesFind.oGlobals.blnRAMAvailRed == true || IssuesFind.oGlobals.blnHDSpaceFreeRed == true ||
                    IssuesFind.oGlobals.blnWiFiEnabledFlag == true || IssuesFind.oGlobals.blnCentralFileOpenFlag == true || 
                    IssuesFind.oGlobals.blnUsersInModelRed == true || IssuesFind.oGlobals.blnWorkingOverWANFlag == true)
                {
                    // Show text in system tray
                    oNotifyIcon.ShowBalloonTip(25000, strTitle, strMessage, ToolTipIcon.Error);
                }
                else
                {
                    // Show text in system tray
                    oNotifyIcon.ShowBalloonTip(25000, strTitle, strMessage, ToolTipIcon.Warning);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Remove the message/icon if displaying
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void NotificationRemove()
        {
            if (oNotifyIcon != null)
            {
                // Remove icon
                oNotifyIcon.Visible = false;

                // End MouseClick event
                oNotifyIcon.MouseClick -= new MouseEventHandler(NotifyIcon_MouseClick);
                oNotifyIcon.BalloonTipClicked -= new EventHandler(NotifyIcon_BalloonTipClicked);

                // Set the object to null
                oNotifyIcon = null;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Handle MouseClick event
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>02/2014</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void NotifyIcon_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                // Show the dashboard
                Dashboard oDashboard = new Dashboard();
                oDashboard.Show();                
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Handle BalloonTipClicked event
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>02/2014</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void NotifyIcon_BalloonTipClicked(object sender, EventArgs e)
        {
            try
            {
                // Show the dashboard
                Dashboard oDashboard = new Dashboard();
                oDashboard.Show();                
            }
            catch
            {
            }
        }
    }
}
