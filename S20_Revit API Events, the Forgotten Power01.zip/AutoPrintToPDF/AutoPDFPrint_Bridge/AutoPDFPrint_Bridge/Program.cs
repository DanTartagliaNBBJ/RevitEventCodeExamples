﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AutoPDFPrint_Bridge.CS
{
    class Program
    {
        public static string strLogfileFullPath = string.Empty;

        static void Main(string[] args)
        {            
            try
            {
                // Get the start date/time
                string strProcessDate = Methods.DateCurrentGet();

                // Log file full path
                strLogfileFullPath = DefaultValues.strLogFilePath + strProcessDate + ".log";

                // Create the log folder if needed
                if (Directory.Exists(DefaultValues.strLogFilePath) == false)
                    Directory.CreateDirectory(DefaultValues.strLogFilePath);

                if (args.Count() != 1)
                {
                    // Write to log file
                    Methods.TextFileWrite(strLogfileFullPath, "Please specify the CFG file name in the Task Scheduler Action's Add argument field: " +
                        Methods.DateCurrentGet() + "-" + Methods.TimeCurrentGet(":") + ", Printing Aborted", true);
                    return;
                }

                // CFG name
                string strPrintCFG = args[0].ToString();

                // Verify the CFG file is found
                if (File.Exists(DefaultValues.strScriptFilePath + strPrintCFG) == false)
                {
                    // Write to log file
                    Methods.TextFileWrite(strLogfileFullPath, "CFG file not found: '" + DefaultValues.strScriptFilePath +
                        strPrintCFG + "': " + Methods.DateCurrentGet() + "-" + Methods.TimeCurrentGet(":") +
                        ", Printing Aborted", true);

                    return;
                }

                // Create the temp folder if needed
                if (Directory.Exists(DefaultValues.strTempPrintPath) == false)
                    Directory.CreateDirectory(DefaultValues.strTempPrintPath);

                // Copy the CFG file into the temp folder
                File.Copy(DefaultValues.strScriptFilePath + strPrintCFG, DefaultValues.strTempPrintPath +
                    strPrintCFG, true);

                // Delete the BIM 360 cache folder
                if (Methods.DeleteCacheFolder() == false)
                {
                    // Write to log file
                    Methods.TextFileWrite(strLogfileFullPath, "Could not delete cache folder: " + Methods.DateCurrentGet() + 
                        "-" + Methods.TimeCurrentGet(":"), true);
                }

                // Launch Revit
                if (Methods.RevitArchLaunch(DefaultValues.strRevitVersion) == false)
                {
                    // Write to log file
                    Methods.TextFileWrite(strLogfileFullPath, "Could not launch Revit " + DefaultValues.strRevitVersion + ": " +
                        Methods.DateCurrentGet() + "-" + Methods.TimeCurrentGet(":") + ", Printing Aborted", true);
                }
            }
            catch(Exception ex)
            {
                // Write to log file
                Methods.TextFileWrite(strLogfileFullPath, "Error: '" + ex.Message + " : " +
                    Methods.DateCurrentGet() + "-" + Methods.TimeCurrentGet(":") +
                    ", Printing Aborted", true);
            }
        }
    }
}
