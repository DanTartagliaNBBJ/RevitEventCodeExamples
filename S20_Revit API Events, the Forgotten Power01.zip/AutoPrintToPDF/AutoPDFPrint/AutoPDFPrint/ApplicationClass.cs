﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using Autodesk.Revit;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Events;

using System.Management;

namespace AutoPDFPrint.CS
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]

    public class ApplicationClass : IExternalApplication
    {
        // Public variables
        public static Autodesk.Revit.DB.Document m_RevitDocument;
        public static UIControlledApplication m_uiControlApp;
        public List<string> strListFromCFG = new List<string>();
        public static string strProcessDate = string.Empty;
        public static string strLogfileFullPath = string.Empty;
        public string strPDFPrintCFG = string.Empty;

        // Implement OnStartup method of IExternalApplication interface.
        public Autodesk.Revit.UI.Result OnStartup(UIControlledApplication application) 
        {
            // Launch Revit normally if temp folder is not found
            if (Directory.Exists(DefaultValues.strTempPrintPath) == false)
                return Autodesk.Revit.UI.Result.Succeeded;

            // Get all CFG files from the temp folder
            List<string> strList = new List<string>();
            strList = Methods.CFGFileGet(DefaultValues.strTempPrintPath);

            // Launch Revit normally if one CFG file is not found
            if (strList.Count != 1)
                return Autodesk.Revit.UI.Result.Succeeded;
            else
                strPDFPrintCFG = strList[0].ToString();

            // Create the logs folder is needed
            if (Directory.Exists(DefaultValues.strLogFilePath) == false)
                Directory.CreateDirectory(DefaultValues.strLogFilePath);

            // Get the start date/time
            strProcessDate = Methods.DateCurrentGet();

            // Log file full path
            strLogfileFullPath = DefaultValues.strLogFilePath + strProcessDate + ".log";

            // Write to log file
            Methods.TextFileWrite(strLogfileFullPath, DefaultValues.strLogFileDblDivide, true);

            // Write to log file
            Methods.TextFileWrite(strLogfileFullPath, "Process Start: " + Methods.DateCurrentGet() + 
                "-" + Methods.TimeCurrentGet(":"), true);

            // Extract the lines of text from CFG file
            strListFromCFG = Methods.CFGValuesGet(strPDFPrintCFG);

            // Delete CFG files in the temp folder
            Methods.CFGFileDelete(DefaultValues.strTempPrintPath);

            // Stop if no lines of text are found
            if (strListFromCFG.Count == 0)
            {
                // Write to log file
                Methods.TextFileWrite(strLogfileFullPath, "No values found in: '" +
                    strPDFPrintCFG + "': " + Methods.DateCurrentGet() +
                    "-" + Methods.TimeCurrentGet(":") + ", Closing Revit", true);

                //Close Revit
                Methods.RevitKill();
            }

            // Intiate the events
            application.Idling += new EventHandler<IdlingEventArgs>(IdlingEvent);
            application.DialogBoxShowing += new EventHandler<DialogBoxShowingEventArgs>(DialogBoxShowingEvent);
            
            return Autodesk.Revit.UI.Result.Succeeded;
        }

        // Implement OnShutdown method of IExternalApplication interface. 
        public Autodesk.Revit.UI.Result OnShutdown(UIControlledApplication application)
        {
            return Autodesk.Revit.UI.Result.Succeeded;
        }

        /*------------------------------------------------------------------------------------**/
        /// IdlingEvent event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public void IdlingEvent(object sender, IdlingEventArgs e)
        {
            int i = 0;            
            string strSheetSet = string.Empty;
            string strPrintSet = string.Empty;
            string strRVTFullPath = string.Empty;
            string strPDFOutPath = string.Empty;
            string strWDrivePath = string.Empty;
            string strProjectGuid = string.Empty;
            string strModelGuid = string.Empty;
            UIApplication uiApp = sender as UIApplication;

            try
            {
                // Itereate through each line of text
                foreach (string strTextLine in strListFromCFG)
                {
                    i++;

                    // Write to log file
                    Methods.TextFileWrite(strLogfileFullPath, DefaultValues.strLogFileDivide, true);

                    // Write to log file
                    Methods.TextFileWrite(strLogfileFullPath, "Processing line " + i.ToString() + 
                        " in CFG file: " + Methods.DateCurrentGet() + "-" + 
                        Methods.TimeCurrentGet(":"), true);

                    // Extract each value into an array
                    string[] strArgArray = strTextLine.Split(',');

                    // Process next line if 4 values are not found
                    if (strArgArray.Count() != 4 && strArgArray.Count() != 5)
                    {
                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, "4 or 5 parameters not found in line: " + 
                            i.ToString() + " in the CFG file processing : " + Methods.DateCurrentGet() +
                            "-" + Methods.TimeCurrentGet(":") + ", Processing next line", true);

                        // Process next line of text
                        continue;
                    }

                    // Process line if 4 values are found
                    if (strArgArray.Count() == 4)
                    {
                        // Get each value and remove beginning and trailing spaces
                        strSheetSet = strArgArray[0].ToString().Trim();
                        strPrintSet = strArgArray[1].ToString().Trim();
                        strRVTFullPath = strArgArray[2].ToString().Trim();
                        strPDFOutPath = strArgArray[3].ToString().Trim();

                        // Verify the RVT file exists
                        if (File.Exists(strRVTFullPath) == false)
                        {
                            // Write to log file
                            Methods.TextFileWrite(strLogfileFullPath, "RVT file not found: '" + strRVTFullPath + "' on line: " +
                                i.ToString() + " : " + Methods.DateCurrentGet() +
                                "-" + Methods.TimeCurrentGet(":") + ", Processing next line", true);

                            break;
                        }

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, "File open start: " + Methods.TimeCurrentGet(":"), true);

                        // Open the RVT detached from Central and open all Worksets
                        Document doc = Methods.OpenRVTDetached(strRVTFullPath, uiApp);

                        // Process next line if Document is null
                        if (doc == null)
                        {
                            // Write to log file
                            Methods.TextFileWrite(strLogfileFullPath, "Could not open file: '" + strRVTFullPath + "' on line: " +
                                i.ToString() + " : " + Methods.DateCurrentGet() +
                                "-" + Methods.TimeCurrentGet(":") + ", Processing next line", true);

                            // Process next line of text
                            continue;
                        }

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, "File open finished: " + Methods.TimeCurrentGet(":"), true);

                        // Print the PDFs
                        Methods.PrintToPDF(strRVTFullPath, strSheetSet, strPrintSet,
                            strPDFOutPath, strProcessDate, strLogfileFullPath, i, doc);

                        // Close the document
                        doc.Close(false);

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, DefaultValues.strLogFileDivide, true);

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, "Process End: " + Methods.DateCurrentGet() +
                            "-" + Methods.TimeCurrentGet(":"), true);

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, DefaultValues.strLogFileDblDivide, true);
                    }
                    else
                    {
                        // Get each value and remove beginning and trailing spaces
                        strSheetSet = strArgArray[0].ToString().Trim();
                        strPrintSet = strArgArray[1].ToString().Trim();
                        strProjectGuid = strArgArray[2].ToString().Trim();
                        strModelGuid = strArgArray[3].ToString().Trim();
                        strPDFOutPath = strArgArray[4].ToString().Trim();

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, "File open start: " + Methods.TimeCurrentGet(":"), true);

                        // Open the BIM 360 RVT and open all Worksets
                        Document doc = Methods.OpenBIM360RVT(strProjectGuid, strModelGuid, uiApp);

                        // Process next line if Document is null
                        if (doc == null)
                        {
                            // Write to log file
                            Methods.TextFileWrite(strLogfileFullPath, "Could not open file: '" + strRVTFullPath + "' on line: " +
                                i.ToString() + " : " + Methods.DateCurrentGet() +
                                "-" + Methods.TimeCurrentGet(":") + ", Processing next line", true);

                            // Process next line of text
                            continue;
                        }

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, "File open finished: " + Methods.TimeCurrentGet(":"), true);

                        // Print the PDFs
                        Methods.PrintToPDF(strRVTFullPath, strSheetSet, strPrintSet,
                            strPDFOutPath, strProcessDate, strLogfileFullPath, i, doc);

                        // Close the document
                        doc.Close(false);

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, DefaultValues.strLogFileDivide, true);

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, "Process End: " + Methods.DateCurrentGet() +
                            "-" + Methods.TimeCurrentGet(":"), true);

                        // Write to log file
                        Methods.TextFileWrite(strLogfileFullPath, DefaultValues.strLogFileDblDivide, true);
                    }
                }

                //Close Revit
                Methods.RevitKill();
            }
            catch(Exception ex)
            {
                // Write to log file
                Methods.TextFileWrite(strLogfileFullPath, "Error: '" + ex.Message + " : " + 
                    Methods.DateCurrentGet() + "-" + Methods.TimeCurrentGet(":") + 
                    ", Processing stopped", true);
            }

            // Exit the events
            m_uiControlApp.DialogBoxShowing -= new EventHandler<DialogBoxShowingEventArgs>(DialogBoxShowingEvent);
            m_uiControlApp.Idling -= new EventHandler<IdlingEventArgs>(IdlingEvent);
        }

        /*------------------------------------------------------------------------------------**/
        /// DialogBoxShowingEvent event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DialogBoxShowingEvent(object sender, DialogBoxShowingEventArgs e)
        {
            try
            {
                // Attempt to click OK to close many typical dialogs that may open
                e.OverrideResult(1);
            }
            catch
            {
            }
        }
    }
}
