﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoPDFPrint.CS
{
    public class DefaultValues
    {
        // Revit version
        public static string strRevitVersion = "2019";

        // Path to main folder
        public static string strMainPrintPath = @"C:\AutoPDFPrint" + strRevitVersion + @"\";

        // Path to temp folder
        public static string strTempPrintPath = strMainPrintPath + @"Temp\";

        // Path for log files
        public static string strLogFilePath = strMainPrintPath + @"Logs\" + Environment.GetEnvironmentVariable("USERNAME") + @"\";

        // Print driver name
        public static string strPrintDriverName = "Adobe PDF";

        // Log file divide line
        public static string strLogFileDivide = "---------------------------------------------------------------------------------------------------------------";

        // Log file double divide line
        public static string strLogFileDblDivide = "===============================================================================================================";

        /*------------------------------------------------------------------------------------**/
    }
}
