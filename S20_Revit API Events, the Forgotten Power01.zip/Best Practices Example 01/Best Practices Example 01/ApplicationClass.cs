﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;

namespace BestPractices01
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class ApplicationClass : IExternalApplication
    {
        // Public variables
        private static UIApplication oUIApplication = null;

        // Implement OnStartup method of IExternalApplication interface.
        public Result OnStartup(UIControlledApplication application)
        {
            application.ControlledApplication.DocumentOpened += new EventHandler<Autodesk.Revit.DB.Events.DocumentOpenedEventArgs>(DocumentOpenedEvent);
            return Result.Succeeded;
        }

        // Implement OnShutdown method of IExternalApplication interface.
        public Result OnShutdown(UIControlledApplication application)
        {
            application.ControlledApplication.DocumentOpened -= new EventHandler<Autodesk.Revit.DB.Events.DocumentOpenedEventArgs>(DocumentOpenedEvent);
            return Result.Succeeded;
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentOpened event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentOpenedEvent(object sender, DocumentOpenedEventArgs e)
        {
            try
            {
                // Do not process non-RVT's
                if (e.Document.IsFamilyDocument)
                    return;

                // Only process Workshared models
                if (e.Document.IsWorkshared == false)
                    return;

                // Get the application
                Autodesk.Revit.ApplicationServices.Application oApplication = sender as Autodesk.Revit.ApplicationServices.Application;
                oUIApplication = new UIApplication(oApplication);

                if (oUIApplication != null)
                {
                    // Open the Worksets dialog
                    WorksetSelect oWorksetSelect = new WorksetSelect(oUIApplication);
                    oWorksetSelect.ShowDialog();
                }                    
            }
            catch
            {                
            }                        
        }
    }
}
